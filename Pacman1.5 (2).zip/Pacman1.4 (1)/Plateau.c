#include <stdio.h>
#include <stdlib.h>
#include "main.h"
#include <windows.h>
#include <time.h>
#include "Personnage.h"

void gotoligcol(int lig, int col)
{
    COORD mycoord;
    mycoord.X =col;
    mycoord.Y = lig;

    SetConsoleCursorPosition(GetStdHandle(STD_OUTPUT_HANDLE), mycoord);
}

void AffichagePacman(Pcman *pcm)
{
    gotoligcol((*pcm).coordonneY,(*pcm).coordonneX);
    if ((*pcm).couleur==0)
    {
        printf(ANSI_COLOR_BLUE"%c",(*pcm).nom);
        printf(ANSI_COLOR_RESET"");
        gotoligcol(25, 55);

    }
    else
    {
        printf(ANSI_COLOR_RED"%c",(*pcm).nom);
        printf(ANSI_COLOR_RESET"");
        gotoligcol(25, 55);
    }

}

void AffichageBlanc(Pcman *pcm)
{
    gotoligcol((*pcm).coordonneY,(*pcm).coordonneX);
    printf(" ");
}

void CreationContour(int largeurTab, int longueurTab, int tab[20][50])
{
    int i;
    for (i=0; i<largeurTab; i++)
    {
        gotoligcol(0,i);
        tab[0][i]='1';
        printf("#");
    }
    for (i=0; i<largeurTab; i++)
    {
        gotoligcol(longueurTab,i);
        tab[longueurTab][i]='1';
        printf("#");
    }
    for (i=0; i<longueurTab; i++)
    {
        gotoligcol(i,0);
        tab[i][0]='1';
        printf("#");
    }
    for (i=0; i<longueurTab; i++)
    {
        gotoligcol(i,largeurTab-1);
        tab[i][largeurTab-1]='1';
        printf("#");
    }
    printf(ANSI_COLOR_RESET"");
}

void GenerationNiveauAlea(int tab[20][50])
{
    int i=2,j=2;
    int nombreMurX=30; // Initialisation arbitraire du nombre de mur qu'on vas poser en ligne
    int MurOuPasMur;   // Boolean, variable al�atoire qui vas d�cider avec 1/2 de poser un mur ou non
    int nombreMurY=20;   // Initialsation arbitraire du nombre de mur qu'on va poser en colonne
    // PS: les initialisations arbitraire corresponde au test effectu� avec un r�sultat le plus satisfaisant
    while(nombreMurX!=0)
    {
        MurOuPasMur=rand()%2; // Une chance sur deux de poser le mur sur cette colonne
        if (MurOuPasMur==0)
        {
            nombreMurX--;     // on d�cr�mante ce nombre
            nombreMurY=20;    // on initialise le nombre de mur qu'on va poser sur cette colonne
            while(nombreMurY!=0)
            {
                MurOuPasMur=rand()%2;  // une chance sur deux de poser le
                if (MurOuPasMur==0)
                {
                    nombreMurY--;
                    tab[j][i]='1';
                    gotoligcol(j,i);
                    printf("#");
                }
                j+=4;
                j=j%18 +2;
            }
        }
        i+=1;
        i=i%48  ;
    }

}

void GenerationAleatoireDeDiamants(int largeurTab,int longueurTab,Objet diamants[5])
{
    int i=0;

    for (i=0; i<5; i++)
    {
        (diamants)[i].coordonneX=(rand()%(50-2)) +1;
        (diamants)[i].coordonneY=(rand()%(20-2)) +1;
        gotoligcol(((diamants)[i]).coordonneY,((diamants)[i]).coordonneX);

        printf(ANSI_COLOR_YELLOW"%c",((diamants)[i]).nom);
        printf(ANSI_COLOR_RESET"");
    }
}

void GenerationAleatoireDePcman(Pcman *pcm)
{
    char tabd[4];
    int i;
    tabd[0]='s';
    tabd[1]='d';
    tabd[2]='q';
    tabd[3]='z';
    i=rand()%4;
    (*pcm).direction=tabd[i];
    (*pcm).coordonneX=(rand()%(50-2)) +1;
    (*pcm).coordonneY=(rand()%(20-2)) +1;

}


void AffichageScore(int *score)
{
    gotoligcol(23,0);
    printf(" Le score est de");
    printf(ANSI_COLOR_RED " %d",*score);
    printf(ANSI_COLOR_RESET"");
}

void AffichagePointDeVie(Pcman *pcm)
{
    gotoligcol(21,0);
    printf(" Il te reste ");
    printf(ANSI_COLOR_MAGENTA "%d ",(*pcm).pointDeVie);
    printf(ANSI_COLOR_RESET"point de vie");
}

int CompteurScore(int *score, Pcman *pcm, Objet diamants[5])
{
    int i=0;

    for (i=0; i<5; i++)
    {
        if (((*pcm).coordonneY==(diamants[i]).coordonneY) && ((*pcm).coordonneX==(diamants[i]).coordonneX))
        {
            (diamants[i]).coordonneY=0;
            (diamants[i]).coordonneX=0;
            *score+=10;

            if ((*pcm).vitesseON==1)
            {
                if((*pcm).vitesse<4)   //Si la vitesse ne d�passe pas d�j� 3, alors elle est incr�ment�e de 1
                    (*pcm).vitesse+=1;
            }
        }
    }

    return *score;
}

void LesFantomesNeMangesPas(Pcman *ennemi, Objet diamants[5])
{
    int i=0;

    for (i=0; i<5; i++)
    {
        if (((*ennemi).coordonneY==(diamants[i]).coordonneY) && ((*ennemi).coordonneX==(diamants[i]).coordonneX))
        {
            gotoligcol((*ennemi).coordonneY,(*ennemi).coordonneX);
            printf(ANSI_COLOR_YELLOW"*");
            printf(ANSI_COLOR_RESET"");
        }
    }
}

void MORT(Pcman *pcm,Pcman ennemi[4])
{
    int i=0;

    for (i=0; i<4; i++)

        if (((ennemi[i]).coordonneY==(*pcm).coordonneY) && ((ennemi[i]).coordonneX==(*pcm).coordonneX))
        {
            (*pcm).pointDeVie-=1;
        }
}
