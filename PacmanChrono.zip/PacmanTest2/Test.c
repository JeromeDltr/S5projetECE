#include <stdio.h>
#include <stdlib.h>
#include "main.h"
#include <windows.h>
#include <time.h>
#include "ListeFonctions.h"

void Clignotement(Pcman *pcm) // Fait clignoter le pacman
{
    // DECLARATION DES VARIABLES
    int i=0;
    for (i=0;i<10;i++)   // on r�p�tes les acitons suivante, on efface le pacman, on attends, on affiche le pacman
    {
         AffichageBlanc(pcm);
         Sleep(2);
         AffichagePacman(pcm);
    }

}

void ToucherCouler(Pcman *pcm,Pcman *ennemi)  //  Test la collision sur un ennemi
{

        if (((*ennemi).coordonneY==(*pcm).coordonneY) && ((*ennemi).coordonneX==(*pcm).coordonneX)) // On test si le fant�me est au m�me endroit que le pacman
        {
            (*pcm).pointDeVie-=1; // On retire un point de vie au pacman
            Clignotement(pcm);  // on le fait clignoter
            if ((*pcm).snakeON==1)  // Si le mode snake est ouvert
            {
                (*pcm).toucher=1;  // on signale que le snake a �t� toucher
            }
        }
}
void boucleToucherCouler(Pcman *pcm, Pcman ennemi[4]) // Test la collision sur tout les ennemis
{
    int i = 0;
    for (i=0;i<4;i++)
    {
        ToucherCouler(pcm,&ennemi[i]);
    }
}
void LesFantomesNeMangesPas(Pcman *ennemi, Objet diamants[5], Objet *Yukunkun)  // Empeche les fantomes de manger des diamants
{
    int i=0;
    SetConsoleTextAttribute(GetStdHandle(STD_OUTPUT_HANDLE), 14);


    for (i=0; i<5; i++)  // On boucle sur tout les diamants
    {
        if (((*ennemi).coordonneY==(diamants[i]).coordonneY) && ((*ennemi).coordonneX==(diamants[i]).coordonneX)) // on test si l'ennemi est sur la m�me position qu'un diamant
        {
            gotoligcol((*ennemi).coordonneY+12,(*ennemi).coordonneX+60); // on se replace � la position du diamant et on l'affiche
            printf("D");
        }
    }
    if (((*ennemi).coordonneY==(*Yukunkun).coordonneY) && ((*ennemi).coordonneX==(*Yukunkun).coordonneX)) // on fait de m�me pour le Yukunkun
        {
            gotoligcol((*ennemi).coordonneY+12,(*ennemi).coordonneX+60);
            printf("*");
        }

    SetConsoleTextAttribute(GetStdHandle(STD_OUTPUT_HANDLE), 15);
}
int CompteurScore(int *score, Pcman *pcm, Objet diamants[5])  // Mets � jours le score
{
    int i=0;

    for (i=0; i<5; i++) // On boucle sur tout les diamants
    {
        if (((*pcm).coordonneY==(diamants[i]).coordonneY) && ((*pcm).coordonneX==(diamants[i]).coordonneX)) // On test si le pacman est � la m�me position qu'un diamant
        {
            // On enleve le diamant du terrain
            (diamants[i]).coordonneY=0;
            (diamants[i]).coordonneX=0;

            *score+=10; // On met � jour le score
            AugmentationVitesse(pcm); // On met � jour la vitesse
        }
    }

    return *score;
}

void TestDefaite(Pcman *pcm, char *key) // Retourne au menu si il y a d�faite
{
    if ((*pcm).pointDeVie<1) // Test si on a 0 point de vie
        {
            system("cls");
            *key='n'; //
        }
    else if ((*pcm).chrono<0)

    {
        system("cls");
            *key='n';
    }
}
void PerteDePointDeVie(Pcman *pcm) // Retire un point de vie au pacman
{
    (*pcm).pointDeVie-=1; // On lui retire et on le fait clignoter
    Clignotement(pcm);
}
int CompteurScoreSnake(int *score, Objet diamants[5], Pcman pcm[100], Objet *Yukunkun)  // Mets � jours le score pour le tableau 6
{
    int i=0,j=0;

    for (i=0; i<5; i++)
    {
        if (((pcm[0]).coordonneY==(diamants[i]).coordonneY) && ((pcm[0]).coordonneX==(diamants[i]).coordonneX))
        {
            (diamants[i]).coordonneY=0;
            (diamants[i]).coordonneX=0;

            *score+=10;


            NouvelleTete(pcm);// On ajoute une t�te
        }
    }

    if (((pcm)[0].coordonneY==(*Yukunkun).coordonneY) && ((pcm)[0].coordonneX==(*Yukunkun).coordonneX))
        {
            (*Yukunkun).coordonneX=0;
            (*Yukunkun).coordonneY=0;
            (*Yukunkun).duree=60;

            (*Yukunkun).nombreDeYukunkun--; // On reduit le nombre de Yukunkun
            *score+=5;  // On met � jours le score
            for (j=0;j<5;j++) // On ajoute les 5 nouvelles t�tes
            {
                NouvelleTete(pcm);
            }
        }
    return *score;
}

void NouvelleTete(Pcman snake[100]) // Ajoute les nouvelles t�tes
{
    (snake[0]).nombreDeTete++; // On met � jour le nombre de t�te
    snake[(snake[0]).nombreDeTete-1].nom='o'; // On lui donne son nom

    // On donne � la nouvelle queux les positions pr�c�dentes, la direction de la queue pr�cedente
    snake[(snake[0]).nombreDeTete-1].direction=snake[(snake[0]).nombreDeTete-2].direction;
    snake[(snake[0]).nombreDeTete-1].coordonneX=snake[(snake[0]).nombreDeTete-2].coordonneXv;
    snake[(snake[0]).nombreDeTete-1].coordonneY=snake[(snake[0]).nombreDeTete-2].coordonneYv;
    snake[(snake[0]).nombreDeTete-1].pointDeVie=snake[(snake[0]).nombreDeTete-2].pointDeVie;
}
void ToucherCouper(Pcman pcm[100],Pcman *ennemi) // Test si il y a collision entre un fant�me et une queux
{
    // DECLARATION DES VARIABLES
    int i,j,taille;
    taille=pcm[0].nombreDeTete + 1;

    for (i=1;i<taille;i++) // pour chacune des queuex
    {
         if (((*ennemi).coordonneY==(pcm)[i].coordonneY) && ((*ennemi).coordonneX==(pcm)[i].coordonneX)) // on test si il y a collision avec l'ennemi
        {
            for (j=i;j<taille;j++)  //  Si oui pour la i-�me, on enleve chacun des queux � partir de la i-�me et on r�duit le nombre de t�te
            {
                AffichageBlanc(&pcm[j]);
                Couper(&pcm[j]);
                pcm[0].nombreDeTete--;

            }
            pcm[0].nombreDeTete++ ; // On ajuste le nombre de t�te
        }
    }
}
void Couper(Pcman *pcm) // Enleve les queux
{
    AffichageBlanc(pcm); // On efface et on rends son deplacement invisible
    (*pcm).nom=' ';
    (*pcm).compteurmvt=0;
    (*pcm).direction='d';
    (*pcm).vitesse=1;
    (*pcm).vitesseON=0;
    (*pcm).couleur=0;

}
void ToucherTete(char *key, unsigned long int *temps, int *score, Pcman pcm[100], Pcman ennemi[4], Objet diamants[5], int tab[20][50], int murOnOff, Objet *Yukunkun)
{
    int j,taille;
    taille=pcm[0].nombreDeTete + 1;
    if((pcm)[0].toucher==1)
    {
        for (j=1;j<taille;j++)
            {
                AffichageBlanc(&pcm[j]);
                Couper(&pcm[j]);
                pcm[0].nombreDeTete--;

            }
        pcm[0].nombreDeTete++;
        (pcm)[0].toucher=0;
        lvl4(key, temps, score,pcm, ennemi, diamants,tab, murOnOff,Yukunkun);

    }
}
void OnSeMordPas(Pcman pcm[100])
{
    int i;

    for (i=1;i<pcm[0].nombreDeTete+1;i++)
    {
        if (((pcm[0]).coordonneY==(pcm)[i].coordonneY) && ((pcm[0]).coordonneX==(pcm)[i].coordonneX))
            {
                pcm[0].pointDeVie--;
                (pcm)[0].toucher=1;
            }
    }
}
void TestVictoirelvl4(Objet diamants[5],char *key)
{
    int i ;
    int compteur=0;
    for (i=0; i<5;i++)
    {
        if (((diamants[i]).coordonneY==0) && ((diamants[i]).coordonneX==0))
        {
            compteur++;
        }

    }
    if (compteur==5)
    {
     *key='n';
     AfficherVictoire();
    }
}
