#include <stdio.h>
#include <stdlib.h>
#include <windows.h>
#include <time.h>
#define LIGNE 20
#define COLONNE 40



typedef struct pacman
{
    int x, y, depx, depy;
} t_pacman;


void gotoligcol( int lig, int col )
{
    COORD mycoord;

    mycoord.X = col;
    mycoord.Y = lig;

    SetConsoleCursorPosition( GetStdHandle( STD_OUTPUT_HANDLE ), mycoord );
}


t_pacman afficheInit(t_pacman pac0)
{
    int posx = rand()%LIGNE;
    int posy = rand()%COLONNE;

    int i=0, j=0;
    for(i=0; i<LIGNE; i++)
    {
        for(j=0; j<COLONNE; j++)
        {
            gotoligcol(i, j);
            if((i==posx)&&(j==posy))
                printf("X");
            else
                printf(" ");
        }
    }

    pac0.depx=0;
    pac0.depy=1;
    pac0.x=posx;
    pac0.y=posy;
    return pac0;
}


void affichageMat(t_pacman pac2)
{
    system("cls");
    gotoligcol(pac2.x-pac2.depx, pac2.y-pac2.depy);
    printf(" ");
    gotoligcol(pac2.x, pac2.y);
    printf("X");

    gotoligcol(5, 60);
    printf("x :   \t  y :   ");
    gotoligcol(5, 60);
    printf("x : %d\t  y : %d", pac2.x, pac2.y);
}


t_pacman deplacement(t_pacman pac3)
{
    if(pac3.y>=COLONNE)
    {
        gotoligcol(pac3.x, pac3.y);
        printf(" ");
        pac3.y=0;
    }

    if(pac3.y<=0)
    {
        gotoligcol(pac3.x, pac3.y);
        printf(" ");
        pac3.y=COLONNE;
    }
    pac3.y+=pac3.depy;

    if(pac3.x>=LIGNE)
    {
        gotoligcol(pac3.x, pac3.y);
        printf(" ");
        pac3.x=0;
    }

    if(pac3.x<=0)
    {
        gotoligcol(pac3.x, pac3.y);
        printf(" ");
        pac3.x=LIGNE;
    }

    pac3.x+=pac3.depx;

    return pac3;
}

int main()
{
    char mat[LIGNE][COLONNE];
    t_pacman pac;
    char key = 'a';
    int compt = 20;

    srand(time(NULL));

    pac = afficheInit(pac);

    while (key !='e')			// �v�nement terminal
    {
        // partie des traitements redondants, vie autonome du programme
        if(compt>2000)
        {
            pac = deplacement(pac);
            compt = 0;
            affichageMat(pac);
        }

        // si �v�nement�
        if (kbhit())			// si une touche est appuy�e (un �v�nement)
        {
            key = getch();		// r�cup�ration du code de la touche

            switch(key)			// analyse du code de la touche (de l��v�nement)
            {
            // et d�clenchement de l�action associ�e
            case 'z' :
                pac.depx=-1;
                pac.depy=0;
                break;
            case 'q' :
                pac.depx=0;
                pac.depy=-1;
                break;
            case 's' :
                pac.depx=1;
                pac.depy=0;
                break;
            case 'd' :
                pac.depx=0;
                pac.depy=1;
                break;

            default :
                key = 'e';
                printf("\n\na bientot !\n\n");
            }
        }
        compt++;
    }

    return 0;
}
