#include <stdio.h>
#include <stdlib.h>
#include "main.h"
#include <time.h>
#include <windows.h>
#include "ListeFonctions.h"

int main()
{
    typedef BOOL (WINAPI *PFONCTION) (HANDLE,DWORD,PCOORD);
    HMODULE hDLL=LoadLibrary("kernel32.dll");
    PFONCTION SetDisplayMode = (PFONCTION) GetProcAddress(hDLL,"SetConsoleDisplayMode");
    HANDLE hconsole = GetStdHandle(STD_OUTPUT_HANDLE);
    COORD coord;
    SetDisplayMode (hconsole,1,&coord);

    // DECLARATION DES VARIABLES
    //Variables li�es � la cr�ation du tableau
    int tab[20][50]= {0};

//Variable li� au menu
    int indiceFleche=0;

//Variables li�es au score
    int score=0;

//Variable de temps
    unsigned long temps=100;
//Variable de boucle infinie
    char key='a';

// Variable pour d�sactiver les murs, initialis� avec bordures
    int murOnOff = 1;

//Creation des variables personnages
    Pcman pcm[100];
    Pcman ennemi[4];
    Objet diamants[5];
    Objet Yukunkun;

    srand(time(NULL));
    PremierEcran();
    menuOption();
    afficherFleche(indiceFleche);

    while (key!='v')
    {
        if(kbhit())
        {
            key=getch();
            switch(key)
            {
            case 'z':
                indiceFleche -=2;
                bougerMenu(indiceFleche);
                break;
            case 's':
                indiceFleche +=2;
                bougerMenu(indiceFleche);
                break;
            case 'e':
                if (modulo(indiceFleche,12) == 0)
                {
                    regles();
                    menuOption();
                    afficherFleche(indiceFleche);
                }
                if (modulo(indiceFleche,12) == 2)
                {
                    ctrlVitesse();
                    choixVitesse(&temps,0);
                    menuOption();
                    afficherFleche(indiceFleche);
                }
                if (modulo(indiceFleche,12) == 4)
                {

                    lvl1(&key, &temps, &score,pcm, ennemi, diamants,tab, murOnOff,&Yukunkun);
                    Reinitialisation(&pcm,ennemi,diamants,tab,&score,&key);
                    menuOption();
                    indiceFleche = 0;
                    afficherFleche(indiceFleche);
                }
                if (modulo(indiceFleche,12) == 6)
                {
                    ReprendreNiveau(&key, &temps, &score,pcm, ennemi, diamants,tab, murOnOff,&Yukunkun);
                    menuOption();
                    indiceFleche = 0;
                    afficherFleche(indiceFleche);
                }
                if (modulo(indiceFleche,12) == 8)
                {
                    OptionMur();
                    choixOptionMur(&murOnOff,0);
                    menuOption();
                    indiceFleche = 0;
                    afficherFleche(indiceFleche);
                }
                if (modulo(indiceFleche,12) == 10)
                {
                    key ='v';
                }

            }
        }

    }

    FinProgramme();
    return 0;
}
