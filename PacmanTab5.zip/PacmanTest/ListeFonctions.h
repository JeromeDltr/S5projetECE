//http://blockofcodes.blogspot.com/2013/06/how-to-change-text-color-of-cc-console.html


//***************************************************PLATEAU********************************************************************************

//to change color

//Cr�ation niveau
void CreationContour( int tab[20][50], int murOnOff);
void GenerationNiveauAlea(int tab[20][50]);

// Placement des personnages et objets
void GenerationAleatoireDeDiamants(Objet diamants[5]);
void GenerationAleatoireDePcman(Pcman *pcm);

//Fonction d'affichage
void AffichagePacman(Pcman *pcm);
void AffichageBlanc(Pcman *pcm);
void AffichageScore(int *score);
void AffichagePointDeVie(Pcman *pcm);

;


//************************************************InitialisationPers***************************************************************

void InitialisationPerso(Pcman *pcm);
void InitialisationObjet(Objet diamants[5]);
void initialisationEnnemi(Pcman ennemi[4]);
void InitialisationEnnemiIA(Pcman ennemi[4]);
void InitialisationVitesseON(Pcman *pcm, Pcman ennemi[4]);
void Reinitialisation(Pcman *pcm, Pcman ennemi[4], Objet diamants[5],int tab[20][50], int *score,char *key);

//***********************************************MENU************************************************************************

void pacmanAffichage();
void PremierEcran();
void menuOption();
void regles();

void bougerMenu(int indiceFleche);
void afficherFleche(int indiceFleche);


void lvl3(char *key, unsigned long int *temps, int *score, Pcman pcm[100], Pcman ennemi[4], Objet diamants[5], int tab[20][50], int murOnOff,Objet *Yukunkun);
void lvl2(char *key, unsigned long int *temps, int *score, Pcman pcm[100], Pcman ennemi[4], Objet diamants[5], int tab[20][50], int murOnOff,Objet *Yukunkun);
void lvl1(char *key, unsigned long int *temps, int *score, Pcman pcm[100], Pcman ennemi[4], Objet diamants[5], int tab[20][50], int murOnOff, Objet *Yukunkun);

void modifVitesse(unsigned long int *temps, int indiceFleche);
void choixVitesse(unsigned long int *temps, int indiceFleche);
void ctrlVitesse();


//************************************************Deplacement*****************************************************************************


void changementDirEnnemie(Pcman *pcm);
void ConditionChangementDir(Pcman *pcm, Pcman *ennemi);
void changementDirIntelligente(Pcman *pcm, Pcman *ennemi);
void ChangementDirPacman(Pcman *pcm, char *key, int *score);

void VieAutonome(Pcman *pcmn,Objet diamants[5], int *score, int tab[20][50],Pcman ennemi[4], int murOnOff);
void VieAutonomeEnnemie(Pcman *ennemi, int tab[20][50], Objet diamants [5], Pcman *pcm, int murOnOff,Objet *Yukunkun);




//*************************************************Test************************************************************************************
void Clignotement(Pcman *pcm);
void TestDefaite(Pcman *pcm, char *key);

int CompteurScore(int *score, Pcman *pcm, Objet diamants[5]);

void ToucherCouler(Pcman *pcm,Pcman *ennemi);
void PerteDePointDeVie(pcm);

void LesFantomesNeMangesPas(Pcman *ennemi, Objet diamants[5], Objet *Yukunkun);
void boucleToucherCouler(Pcman *pcm, Pcman ennemi[4]);

//**************************************************OutilsAutres**************************************************************************
int MinTab(double tab[4], int tailleTab);
int modulo(int x,int N);
void gotoligcol(int lig, int col);

//********************************************************Snake*********
void lvl4(char *key, unsigned long int *temps, int *score, Pcman pcm[100], Pcman ennemi[4], Objet diamants[5], int tab[20][50], int murOnOff,Objet *Yukunkun);
int CompteurScoreSnake(int *score,Objet diamants[5], Pcman pcm[100], Objet *Yukunkun) ;
void InitialisationSnake(Pcman pcm[100]);
void NouvelleTete(Pcman pcm[100]);

void DeplacementSnake(Pcman pcm[100], int jsp);
void VieAutonomeSnake(Pcman *pcms,int tab[20][50], Pcman ennemi[4],int jsp, Pcman pcm[100]);
void InitialisationYukunkun(Objet *Yukunkun);
void GenerationAleatoireObjet(Objet *objet);
void Duree(Objet *objet);
void ToucherCouper(Pcman pcm[100],Pcman *ennemi);
void Couper(Pcman *pcm);
void ToucherTete(char *key, unsigned long int *temps, int *score, Pcman pcm[100], Pcman ennemi[4], Objet diamants[5], int tab[20][50], int murOnOff, Objet *Yukunkun);
void OnSeMordPas(Pcman pcm[100]);
void TestVictoirelvl4(Objet diamants[5],char *key);

//lvl 5///////////////////////////////////////////////////////////////////////////////////////////////////////////////////
void ReinitialisationTab(int tab[20][50]);
void ReductionContour(int tab[20][50], int murOnOff, int largeur, int longueur, int reduction, Pcman ennemi[4]);
void lvl5(char *key, unsigned long int *temps, int *score, Pcman pcm[100], Pcman ennemi[4], Objet diamants[5], int tab[20][50], int murOnOff, Objet *Yukunkun);
void RegenerationDiamants(Objet diamants[5], int tab[20][50]);
void RegenerationEnnemi(Objet ennemi[4], int tab[20][50]);
void ReductionDEContour(int tab[20][50], int murOnOff, int largeur, int longueur, int reduction);
/// lvl6////
void CreationPortail(int tab[20][50]);
void CreationContour6(int tab[20][50], int murOnOff);
void lvl6(char *key, unsigned long int *temps, int *score, Pcman pcm[100], Pcman ennemi[4], Objet diamants[5], int tab[20][50], int murOnOff, Objet *Yukunkun);
