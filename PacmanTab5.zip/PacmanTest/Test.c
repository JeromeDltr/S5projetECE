#include <stdio.h>
#include <stdlib.h>
#include "main.h"
#include <windows.h>
#include <time.h>
#include "ListeFonctions.h"

void Clignotement(Pcman *pcm)
{
    int i=0;
    for (i=0;i<10;i++)
    {

         AffichageBlanc(pcm);
         Sleep(2);
         AffichagePacman(pcm);

    }

}

void ToucherCouler(Pcman *pcm,Pcman *ennemi)  //  Test si un ennemi � touch� le pacman
{

        if (((*ennemi).coordonneY==(*pcm).coordonneY) && ((*ennemi).coordonneX==(*pcm).coordonneX))
        {
            (*pcm).pointDeVie-=1;
            Clignotement(pcm);
            if ((*pcm).snakeON==1)
            {
                (*pcm).toucher=1;
            }
        }
}
void boucleToucherCouler(Pcman *pcm, Pcman ennemi[4]) // Test la colission sur tout les ennemis
{
    int i = 0;
    for (i=0;i<4;i++)
    {
        ToucherCouler(pcm,&ennemi[i]);
    }
}
void LesFantomesNeMangesPas(Pcman *ennemi, Objet diamants[5], Objet *Yukunkun)  // Empeche les fantomes de manger des diamants
{
    int i=0;
    SetConsoleTextAttribute(GetStdHandle(STD_OUTPUT_HANDLE), 14);
    for (i=0; i<5; i++)
    {
        if (((*ennemi).coordonneY==(diamants[i]).coordonneY) && ((*ennemi).coordonneX==(diamants[i]).coordonneX))
        {
            gotoligcol((*ennemi).coordonneY+12,(*ennemi).coordonneX+60);
            printf("D");
        }
    }
    if (((*ennemi).coordonneY==(*Yukunkun).coordonneY) && ((*ennemi).coordonneX==(*Yukunkun).coordonneX))
        {
            gotoligcol((*ennemi).coordonneY+12,(*ennemi).coordonneX+60);
            printf("*");
        }

    SetConsoleTextAttribute(GetStdHandle(STD_OUTPUT_HANDLE), 15);
}
int CompteurScore(int *score, Pcman *pcm, Objet diamants[5])  // Mets � jours le score
{
    int i=0;

    for (i=0; i<5; i++)
    {
        if (((*pcm).coordonneY==(diamants[i]).coordonneY) && ((*pcm).coordonneX==(diamants[i]).coordonneX))
        {
            (diamants[i]).coordonneY=0;
            (diamants[i]).coordonneX=0;
            (diamants[i]).manger=1;

            *score+=10;
            AugmentationVitesse(pcm);
        }
    }

    return *score;
}

void TestDefaite(Pcman *pcm, char *key)
{
    if ((*pcm).pointDeVie<1)
        {
            system("cls");
            *key='n';
        }

}
void PerteDePointDeVie(Pcman *pcm)
{
    (*pcm).pointDeVie-=1;
    Clignotement(pcm);
}
int CompteurScoreSnake(int *score, Objet diamants[5], Pcman pcm[100], Objet *Yukunkun)  // Mets � jours le score
{
    int i=0,j=0;

    for (i=0; i<5; i++)
    {
        if (((pcm[0]).coordonneY==(diamants[i]).coordonneY) && ((pcm[0]).coordonneX==(diamants[i]).coordonneX))
        {
            (diamants[i]).coordonneY=0;
            (diamants[i]).coordonneX=0;
            *score+=10;
            NouvelleTete(pcm);
        }
    }

    if (((pcm)[0].coordonneY==(*Yukunkun).coordonneY) && ((pcm)[0].coordonneX==(*Yukunkun).coordonneX))
        {
            (*Yukunkun).coordonneX=0;
            (*Yukunkun).coordonneY=0;
            (*Yukunkun).duree=60;

            (*Yukunkun).nombreDeYukunkun--;
            *score+=5;
            for (j=0;j<5;j++)
            {
                NouvelleTete(pcm);
            }
        }
    return *score;
}

void NouvelleTete(Pcman snake[100])
{
    (snake[0]).nombreDeTete++;
    snake[(snake[0]).nombreDeTete-1].nom='o';
    snake[(snake[0]).nombreDeTete-1].direction=snake[(snake[0]).nombreDeTete-2].direction;
    snake[(snake[0]).nombreDeTete-1].coordonneX=snake[(snake[0]).nombreDeTete-2].coordonneXv;
    snake[(snake[0]).nombreDeTete-1].coordonneY=snake[(snake[0]).nombreDeTete-2].coordonneYv;
    snake[(snake[0]).nombreDeTete-1].pointDeVie=snake[(snake[0]).nombreDeTete-2].pointDeVie;
}
void ToucherCouper(Pcman pcm[100],Pcman *ennemi)
{
    int i,j,taille;
    taille=pcm[0].nombreDeTete + 1;
    for (i=1;i<taille;i++)
    {
         if (((*ennemi).coordonneY==(pcm)[i].coordonneY) && ((*ennemi).coordonneX==(pcm)[i].coordonneX))
        {
            for (j=i;j<taille;j++)
            {
                AffichageBlanc(&pcm[j]);
                Couper(&pcm[j]);
                pcm[0].nombreDeTete--;

            }
            pcm[0].nombreDeTete++ ;
        }
    }
}
void Couper(Pcman *pcm)
{
    AffichageBlanc(pcm);
    (*pcm).nom=' ';
    (*pcm).compteurmvt=0;
    (*pcm).direction='d';
    (*pcm).vitesse=1;
    (*pcm).vitesseON=0;
    (*pcm).couleur=0;

}
void ToucherTete(char *key, unsigned long int *temps, int *score, Pcman pcm[100], Pcman ennemi[4], Objet diamants[5], int tab[20][50], int murOnOff, Objet *Yukunkun)
{
    int j,taille;
    taille=pcm[0].nombreDeTete + 1;
    if((pcm)[0].toucher==1)
    {
        for (j=1;j<taille;j++)
            {
                AffichageBlanc(&pcm[j]);
                Couper(&pcm[j]);
                pcm[0].nombreDeTete--;

            }
        pcm[0].nombreDeTete++;
        (pcm)[0].toucher=0;
        lvl4(key, temps, score,pcm, ennemi, diamants,tab, murOnOff,Yukunkun);

    }
}
void OnSeMordPas(Pcman pcm[100])
{
    int i;

    for (i=1;i<pcm[0].nombreDeTete+1;i++)
    {
        if (((pcm[0]).coordonneY==(pcm)[i].coordonneY) && ((pcm[0]).coordonneX==(pcm)[i].coordonneX))
            {
                pcm[0].pointDeVie--;
                (pcm)[0].toucher=1;
            }
    }
}
void TestVictoirelvl4(Objet diamants[5],char *key)
{
    int i ;
    int compteur=0;
    for (i=0; i<5;i++)
    {
        if (((diamants[i]).coordonneY==0) && ((diamants[i]).coordonneX==0))
        {
            compteur++;
        }

    }
    if (compteur==5)
    {
     *key='n';
     AfficherVictoire();
    }
}
