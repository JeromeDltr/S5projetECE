
#include <stdio.h>
#include <stdlib.h>
#include "main.h"
#include <windows.h>
#include <time.h>
#include "ListeFonctions.h"



// INITIALISATION DES PARAMETRES
void InitialisationPerso(Pcman *pcm) // Initialise les attributs du pacman
{
    int i;
    (*pcm).nom='X';
    (*pcm).coordonneX=2;
    (*pcm).coordonneY=2;
    (*pcm).compteurmvt=0;
    (*pcm).direction='d';
    (*pcm).pointDeVie=5;
    (*pcm).vitesse=1;
    (*pcm).vitesseON=0;
    (*pcm).couleur=0;
    (*pcm).nombreDeTete=1;
    (*pcm).snakeON=0;
    (*pcm).toucher=0;
    for(i=1; i<100; i++)
    {
        (pcm[i]).nom=' ';
        (pcm[i]).coordonneX=0;
        (pcm[i]).coordonneY=0;
        (pcm[i]).coordonneXv=0;
        (pcm[i]).coordonneYv=0;
        (pcm[i]).pointDeVie=5;
        (pcm[i]).compteurmvt=0;
        (pcm[i]).direction='d';
        (pcm[i]).couleur=0;
        (pcm[i]).vitesse=1;
        (pcm[i]).vitesseON=0;
    }
}
void InitialisationSnake(Pcman snake[100]) // Initialise les attributs du pacman
{
    (snake[0]).snakeON=1;

}
void InitialisationYukunkun(Objet *Yukunkun)
{

    (*Yukunkun).nom='*';
    (*Yukunkun).coordonneX=0;
    (*Yukunkun).coordonneY=0;
    (*Yukunkun).duree=100;
    (*Yukunkun).nombreDeYukunkun=1;

}

void InitialisationObjet(Objet diamants[5]) // Initialise les attributs des Objets
{
    int i;

    for(i=0; i<5; i++)
    {
        (diamants)[i].nom='D';
        (diamants)[i].coordonneX=0;
        (diamants)[i].coordonneY=0;
        (diamants)[i].manger=0;
    }
}
void initialisationEnnemi(Pcman ennemi[4]) // Initialise les attributs des ennemis
{
    int i;
    for(i=0; i<4; i++)
    {
        (ennemi[i]).nom='E';
        (ennemi[i]).coordonneX=0;
        (ennemi[i]).coordonneY=0;
        (ennemi[i]).compteurmvt=0;
        (ennemi[i]).direction='d';
        (ennemi[i]).couleur=1;
        (ennemi[i]).vitesse=1;
        (ennemi[i]).IAON=0;
    }
}
void InitialisationEnnemiIA(Pcman ennemi[4])  // Active l'intelligense des ennemis
{
    int i;
    for(i=0; i<4; i++)
        (ennemi[i]).IAON='1';
}

void InitialisationVitesseON(Pcman *pcm, Pcman ennemi[4]) // Active le changement de vitesse des ennemis
{
    (*pcm).vitesseON=1;
    (ennemi[0]).vitesse=1;
    (ennemi[1]).vitesse=1;
    (ennemi[2]).vitesse=2;
    (ennemi[3]).vitesse=2;
}
void Reinitialisation(Pcman *pcm, Pcman ennemi[4], Objet diamants[5],int tab[20][50], int *score,char *key)
{
    int i,j;
    initialisationEnnemi(ennemi);
    InitialisationObjet(diamants);
    InitialisationPerso(pcm);
    for (j=0;j<20;j++)
    {
        for (i=0;i<50;i++)
        {
            tab[j][i]=0;
        }
    }
}
void ReinitialisationTab(int tab[20][50])
{

    int i,j;
    for (j=0;j<20;j++)
    {
        for (i=0;i<50;i++)
        {
            tab[j][i]=0;
        }
    }

}
void Duree(Objet *objet)
{
    int i;
    (*objet).duree--;
    if ((*objet).duree==0)
    {
        AffichageBlanc(objet);
        (*objet).coordonneX=0;
        (*objet).coordonneY=0;
        (*objet).duree=60;
        (*objet).nombreDeYukunkun--;

    }
}
