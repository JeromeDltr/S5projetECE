#include <stdio.h>
#include <stdlib.h>
#include "main.h"
#include <time.h>
#include <windows.h>
#include "conio.h"
#include "ListeFonctions.h"

void afficherFleche(int indiceFleche)
{

    gotoligcol(indiceFleche+3+12,65);
    printf("->");
}

void pacmanAffichage()
{
    /*for(int i = 0; i<205; i++)
    {

    SetConsoleTextAttribute(GetStdHandle(STD_OUTPUT_HANDLE), i);
    printf("Text Color %d\n", i);
    //printf("#");
    }*/

    SetConsoleTextAttribute(GetStdHandle(STD_OUTPUT_HANDLE), 12);

    gotoligcol(0+12, 50);
    printf("         _______  _______  _______  _______  _______  _       ");gotoligcol(1+12, 50);
    printf("        (  ____ )(  ___  )(  ____ \\(       )(  ___  )( (    /|");gotoligcol(2+12, 50);
    printf("        | (    )|| (   ) || (    \\/| () () || (   ) ||  \\  ( |");gotoligcol(3+12, 50);
    printf("        | (____)|| (___) || |      | || || || (___) ||   \\ | |");gotoligcol(4+12, 50);
    printf("        |  _____)|  ___  || |      | |(_)| ||  ___  || (\\ \\) |");gotoligcol(5+12, 50);
    printf("        | (      | (   ) || |      | |   | || (   ) || | \\   |");gotoligcol(6+12, 50);
    printf("        | )      | )   ( || (____/\\| )   ( || )   ( || )  \\  |");gotoligcol(7+12, 50);
    printf("        |/       |/     \\|(_______/|/     \\||/     \\||/    )_| ");
    SetConsoleTextAttribute(GetStdHandle(STD_OUTPUT_HANDLE), 15);
}

void AfficherVictoire()
{
    char key;
    system("cls");
    SetConsoleTextAttribute(GetStdHandle(STD_OUTPUT_HANDLE), 10);

    gotoligcol(0+12, 40);
    printf("      ##                   ##\n");gotoligcol(1+12, 40);
    printf("       #.#                 , #.#\n");gotoligcol(2+12, 40);
    printf("     ( #####               ######,\n");gotoligcol(3+12, 40);
    printf("    # #####/#             #(##### #\n");gotoligcol(4+12, 40);
    printf("    ######## ,           ( ########\n");gotoligcol(5+12, 40);
    printf("    ##########     /     ##########\n");gotoligcol(6+12, 40);
    printf("    #########(#   #(#   ###########\n");gotoligcol(7+12, 40);
    printf("     ##########\(/ ### /# #########\n");gotoligcol(8+12, 40);
    printf("      #########  #####  #########\n");gotoligcol(9+12, 40);
    printf("     #  #######  #####  #######  #\n");gotoligcol(10+12, 40);
    printf("     \(\(#  #### ## ### ## ####  ###     ####  ######  ########  #######   #### ########  ########   #### \n");gotoligcol(11+12, 40);
    printf("     # ##/ ## ####   #### ## ###        ##  ##    ##    ##    ##     ##   ##  ##     ## ##         #### \n");gotoligcol(12+12, 40);
    printf("        #.# (######,######\( #,#         ##  ##          ##    ##     ##   ##  ##     ## ##          ## \n");gotoligcol(13+12, 40);
    printf("          ####################          ##  ##          ##    ##     ##   ##  ########  ######   \n");gotoligcol(14+12, 40);
    printf("         ##/ # ##.   .## # *#(          ##  ##          ##    ##     ##   ##  ##   ##   ##      \n");gotoligcol(15+12, 40);
    printf("         ###  # ####### #  ##(          ##  ##    ##    ##    ##     ##   ##  ##    ##  ##         #### \n");gotoligcol(16+12, 40);
    printf("               # ##### #               ####  ######     ##     #######   #### ##     ## ########   #### \n");gotoligcol(17+12, 40);
    printf("                #####,#\n");gotoligcol(18+12, 40);
    printf("                  \(#\)\n");
    SetConsoleTextAttribute(GetStdHandle(STD_OUTPUT_HANDLE), 15);

    key=getch();
}

void AfficherDefaite()
{
    char key;
    system("cls");
    SetConsoleTextAttribute(GetStdHandle(STD_OUTPUT_HANDLE), 4);

    gotoligcol(10+12, 40);
    printf("########   ########  ########     ###     ####  ########  ########      #### \n");
    gotoligcol(11+12, 40);
    printf("##     ##  ##        ##          ## ##     ##      ##     ##            #### \n");
    gotoligcol(12+12, 40);
    printf("##     ##  ##        ##         ##   ##    ##      ##     ##             ## \n");
    gotoligcol(13+12, 40);
    printf("##     ##  #####     #####     ##     ##   ##      ##     #####     \n");
    gotoligcol(14+12, 40);
    printf("##     ##  ##        ##        #########   ##      ##     ##          \n");
    gotoligcol(15+12, 40);
    printf("##     ##  ##        ##        ##     ##   ##      ##     ##            #### \n");
    gotoligcol(16+12, 40);
    printf("########   ########  ##        ##     ##  ####     ##     ########      #### \n");
    SetConsoleTextAttribute(GetStdHandle(STD_OUTPUT_HANDLE), 15);

    key=getch();
}

void PremierEcran()
{
    char keys='a';
    pacmanAffichage();
    gotoligcol(10+12,70);
    printf("Par : ");
    SetConsoleTextAttribute(GetStdHandle(STD_OUTPUT_HANDLE), 240);
    printf("Maxence, Remi et Jerome");
    SetConsoleTextAttribute(GetStdHandle(STD_OUTPUT_HANDLE), 15);
    gotoligcol(15+12,72);
    printf("Appuyer pour continuer");

    keys=getch();
}
void regles()//explication des r�gles
{
    char keys='b';
    system("cls");
    gotoligcol(3+12,60);
    printf("Le PACMAN est un jeu classique dans lequel un personnage se deplace");gotoligcol(4+12,60);
    printf("dans un espace plus ou moins complexe pour manger des diamants.");gotoligcol(7+12,60);
    printf("Il peut aller dans 4 directions a l\'aide du clavier et doit eviter");gotoligcol(8+12,60);
    printf("de se faire attraper par des fantomes qui sillonnent l\'espace de jeu.");gotoligcol(10+12,60);
    printf("Les touches de deplacement sont ");
    SetConsoleTextAttribute(GetStdHandle(STD_OUTPUT_HANDLE), 12);
    printf("z,q,s,d.");
    SetConsoleTextAttribute(GetStdHandle(STD_OUTPUT_HANDLE), 15);gotoligcol(13+12,60);
    printf("Appuyer pour continuer");

    keys=getch();
}
void menuOption()
{
    system("cls");
    gotoligcol(3+12,70);
    printf("1. rules");gotoligcol(5+12,70);
    printf("2. reglage de la vitesse");gotoligcol(7+12,70);
    printf("3. Nouvelle Partie");gotoligcol(9+12,70);
    printf("4. Reprendre Partie");gotoligcol(11+12,70);
    printf("5. Bordure");gotoligcol(13+12,70);
    printf("6. Quitter");gotoligcol(16+12,70);
    printf("Appuyer sur e pour valider");
}
void bougerMenu(int indiceFleche)
{
    menuOption();
    afficherFleche((modulo(indiceFleche,12)));
}

void ctrlVitesse()//Sert � d�finir la vitesse du jeu
{
    system("cls");
    gotoligcol(3+12,70);
    printf("Lent");gotoligcol(5+12,70);
    printf("Modere ");gotoligcol(7+12,70);
    printf("Rapide");gotoligcol(10+12,70);
    printf("Appuyer sur e pour valider");
}

void modifVitesse(unsigned long int *temps, int indiceFleche)//Pour afficher la vitesse choisi dans le menu "vitesse"
{
    ctrlVitesse();
    afficherFleche(modulo(indiceFleche,6));
}

void choixVitesse(unsigned long int *temps, int indiceFleche)//pour choisir la vitesse du jeu
{
    char keys='b';
    char answer='b';
    afficherFleche(indiceFleche);
    while (keys!='m')
    {
        if(kbhit())
        {
            answer=getch();
            switch (answer)
            {
            case 'z':
                indiceFleche -= 2;
                modifVitesse(&temps,indiceFleche);
                break;
            case 's':
                indiceFleche += 2;
                modifVitesse(&temps,indiceFleche);
                break;
            case 'e':
                if (modulo(indiceFleche,6)==0)
                {
                    *temps = 90;
                    keys = 'm';
                }
                if (modulo(indiceFleche,6)==2)
                {
                    *temps = 50;
                    keys = 'm';
                }
                if (modulo(indiceFleche,6)== 4)
                {
                    *temps = 20;
                    keys ='m';
                }

            }
        }
    }
}

void SauvegardeNiveau(int *score)
{
    FILE* sauvegarde = NULL;

    sauvegarde = fopen("sauvegarde.txt", "w");
    if (sauvegarde != NULL)
    {
        fprintf(sauvegarde,"%d\n",*score);
    }
    else
    {
        printf("Impossible d'ouvrir le fichier sauvegarde :(");
    }
    fclose(sauvegarde);

}


void ReprendreNiveau(char *key, unsigned long int *temps, int *score, Pcman pcm[100], Pcman ennemi[4], Objet diamants[100], int tab[20][50], int murOnOff,Objet *Yukunkun)
{
    FILE* sauvegarde = NULL;
    char entier[10];
    *score = 0;


    sauvegarde = fopen("sauvegarde.txt", "r");
    if (sauvegarde != NULL)
    {
        fgets(entier,10,sauvegarde);//On lit la premiere ligne du fichier de sauvegarde
        (*score) = atoi(entier);//On recupere le chiffre qui correspond au score sauvegarde
    }
    else
    {
        printf("Aucune sauvegarde disponible!");
    }
    fclose(sauvegarde);

    system("cls");
    lvl1(key, temps, score, pcm, ennemi, diamants,tab, murOnOff,Yukunkun);
    Reinitialisation(&pcm,ennemi,diamants,tab,&score,&key);


}

void bougerOptionMur(int murOnOff,int indiceFleche)
{
    OptionMur(murOnOff);
    afficherFleche(modulo(indiceFleche,4));
}

void OptionMur()//Sert � d�finir la vitesse du jeu
{
    system("cls");
    gotoligcol(3+12,70);
    printf("On");gotoligcol(5+12,70);
    printf("Off");
}

void choixOptionMur(int*murOnOff, int indiceFleche)
{
    indiceFleche = 0;
    afficherFleche(indiceFleche);
    char keys = 'a';
    char key;
    while (keys!='v')
    {
        if(kbhit())
        {
            key=getch();
            switch(key)
            {
            case 'z':
                indiceFleche -=2;
                bougerOptionMur(*murOnOff,indiceFleche);
                break;
            case 's':
                indiceFleche +=2;
                bougerOptionMur(*murOnOff,indiceFleche);
                break;
            case 'e':
                if (modulo(indiceFleche,4) == 0)
                {
                    *murOnOff = 1;
                }
                if (modulo(indiceFleche,4) == 2)
                {
                    *murOnOff = 0;
                }
                keys ='v';
                break;
            }
        }
    }
}

void FinProgramme()
{
    system("cls");
    SetConsoleTextAttribute(GetStdHandle(STD_OUTPUT_HANDLE), 14);
    gotoligcol(10+12, 70);
    printf("Au revoir !");
    SetConsoleTextAttribute(GetStdHandle(STD_OUTPUT_HANDLE), 0);
}
