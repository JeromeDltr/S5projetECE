
#include <stdio.h>
#include <stdlib.h>
#include "main.h"
#include <windows.h>
#include <time.h>
#include "ListeFonctions.h"


void lvl5(char *key, unsigned long int *temps, int *score, Pcman pcm[100], Pcman ennemi[4], Objet diamants[5], int tab[20][50], int murOnOff, Objet *Yukunkun)
{
    int compteurmur=0;
    int largeur =20,longueur=50, reduction=0;
    int val1=0, val2 = 0, val3 = 0;
    int ON=0;
    system("cls");

    InitialisationDiamantsManger(diamants);
    initialisationEnnemi(ennemi); //Initialise les
    CreationContour(tab, murOnOff);
    // Creation du niveau
    GenerationAleatoireDePcman(&pcm[0]);
    GenerationAleatoireDePcman(&ennemi[0]);
    GenerationAleatoireDePcman(&ennemi[1]);
    GenerationAleatoireDePcman(&ennemi[2]);
    GenerationAleatoireDePcman(&ennemi[3]);

    AffichagePacman(&pcm[0]);
    GenerationAleatoireDeDiamants(diamants);
    while (*key!='n')
    {
        val2 = 1- val2;
        Sleep(*temps);

        if(val3>=5-(*pcm).vitesse)
        {
            VieAutonome(&pcm[0], diamants,score,tab,ennemi, murOnOff);
            val3=0;
        }
        if(val2==0)
        {
            val1 = 1 - val1;

            if(val1 == 0)
            {
                VieAutonomeEnnemie(&ennemi[0],tab,diamants,&pcm[0], murOnOff,Yukunkun);
                VieAutonomeEnnemie(&ennemi[1],tab,diamants,&pcm[0], murOnOff,Yukunkun);
                VieAutonomeEnnemie(&ennemi[2],tab,diamants,&pcm[0], murOnOff,Yukunkun);      // ces 2 vont moins vite que les 2 autres ennemis
                VieAutonomeEnnemie(&ennemi[3],tab,diamants,&pcm[0], murOnOff,Yukunkun);
                if (ON>=1 && ON <14)
                {
                    ReductionContour(tab,murOnOff,largeur,longueur,reduction,ennemi);
                    ON++;
                }
            }
        }
        val3++;
        TestDefaite(&pcm[0],key,score);
        ChangementDirPacman(&pcm[0],key,score);
        *score=CompteurScore(score,&pcm[0],diamants);
        AffichageScore(score);

        if (compteurmur==100)
        {
            ReductionDEContour(tab,murOnOff,largeur,longueur,reduction);
            longueur--;
            largeur--;
            reduction++;
            ReductionContour(tab,murOnOff,largeur,longueur,reduction,ennemi);
            compteurmur=0;
            RegenerationDiamants(diamants,tab);
            ON=1;
        }
        if (TestVictoirelvl4(diamants,key))
        {
            *key='n';
            (diamants[0]).nombreDeDiamants+=5;
            AfficherVictoire();
        }
        TestDefaite(&pcm[0],key,score);
        compteurmur++;
    }
}

void lvl4(char *key, unsigned long int *temps, int *score, Pcman pcm[100], Pcman ennemi[4], Objet diamants[100], int tab[20][50], int murOnOff, Objet *Yukunkun)
{
    int i=0;
    int randi;
    int val1 = 0, val2 = 0, val3 = 0;

    system("cls");
    InitialisationSnake(pcm);
    InitialisationYukunkun(Yukunkun);

    CreationContour(tab, murOnOff);// Creation du niveau

    GenerationAleatoireDePcman(&pcm[0]);

    AffichagePacman(&pcm[0]);

    GenerationAleatoireDePcman(&ennemi[0]);
    GenerationAleatoireDePcman(&ennemi[1]);
    GenerationAleatoireDePcman(&ennemi[2]);
    GenerationAleatoireDePcman(&ennemi[3]);
    GenerationAleatoireDeDiamants(diamants);


    while (*key!='n')
    {
        val2 = 1- val2;
        randi=rand()%80;
        Sleep(*temps);
        if(val3>=5-(*pcm).vitesse)
        {

            VieAutonome(&pcm[0], diamants,score,tab,ennemi, murOnOff);
            OnSeMordPas(pcm);
            for (i=1;i<(pcm)[0].nombreDeTete;i++)
            {

                VieAutonomeSnake(&pcm[i],tab,ennemi,i,pcm);
            }
            val3=0;
        }

        if(val2==0)
        {
            val1 = 1 - val1;

            if(val1 == 0)
            {
                VieAutonomeEnnemie(&ennemi[0],tab,diamants,&pcm[0], murOnOff,Yukunkun);
                VieAutonomeEnnemie(&ennemi[1],tab,diamants,&pcm[0], murOnOff,Yukunkun);
                VieAutonomeEnnemie(&ennemi[2],tab,diamants,&pcm[0], murOnOff,Yukunkun);      // ces 2 vont moins vite que les 2 autres ennemis
                VieAutonomeEnnemie(&ennemi[3],tab,diamants,&pcm[0], murOnOff,Yukunkun);
                ToucherTete(key, temps, score,pcm, ennemi, diamants,tab, murOnOff,Yukunkun);
            }
        }


        val3++;
        *score=CompteurScoreSnake(score,diamants,pcm,Yukunkun);
        AffichageScore(score);
        ChangementDirPacman(&pcm[0], key, score);

        if ((randi==7)&& (*Yukunkun).nombreDeYukunkun==1 )
        {
            GenerationAleatoireObjet(Yukunkun);
        }
        if ((*Yukunkun).nombreDeYukunkun!=1)
        {
            Duree(Yukunkun);
        }
        if (TestVictoirelvl4(diamants,key))
        {
            lvl5(key, temps, score,pcm, ennemi, diamants,tab, murOnOff,Yukunkun);

        }
        TestDefaite(&pcm[0],key,score);
    }
}

void lvl3(char *key, unsigned long int *temps, int *score, Pcman pcm[100], Pcman ennemi[4], Objet diamants[100], int tab[20][50], int murOnOff, Objet *Yukunkun)
{
    int val1 = 0, val2 = 0, val3 = 0, val4=0;
    system("cls");
    if (*score==150*((diamants[0]).nombreDeDiamants/5))
        {
            Reinitialisation(&pcm[0],ennemi,diamants,tab,score,key);
            lvl4(key, temps, score,pcm, ennemi, diamants,tab, murOnOff,Yukunkun);
        }
    CreationContour(tab, murOnOff);
    GenerationNiveauAlea(tab);
    InitialisationEnnemiIA(ennemi);// Creation du niveau
    InitialisationVitesseON(&pcm[0], ennemi);
    GenerationAleatoireDePcman(&pcm[0]);
    GenerationAleatoireDePcman(&ennemi[0]);
    GenerationAleatoireDePcman(&ennemi[1]);
    GenerationAleatoireDePcman(&ennemi[2]);
    GenerationAleatoireDePcman(&ennemi[3]);

    AffichagePacman(pcm);
    GenerationAleatoireDeDiamants(diamants);
    *score=100*((diamants[0]).nombreDeDiamants/5);
    while (*key!='n')
    {

        val4 = 1- val4;
        Sleep(*temps);

        if(val3>=5-(*pcm).vitesse)
        {
            Teleporter(&pcm[0]); // On test si on est sur la case pour se teleporter
            VieAutonome(&pcm[0], diamants,score,tab,ennemi, murOnOff);
            val3=0;
        }
        if (val4==0)
        {
           val2=1-val2;
           if(val2==0)
        {
            val1 = 1 - val1;
            VieAutonomeEnnemie(&ennemi[0],tab,diamants,&pcm[0], murOnOff,Yukunkun);
            VieAutonomeEnnemie(&ennemi[1],tab,diamants,&pcm[0], murOnOff,Yukunkun);
            if(val1 == 0)
            {
                VieAutonomeEnnemie(&ennemi[2],tab,diamants,&pcm[0], murOnOff,Yukunkun);      // ces 2 vont moins vite que les 2 autres ennemis
                VieAutonomeEnnemie(&ennemi[3],tab,diamants,&pcm[0], murOnOff,Yukunkun);
            }
        }
        }


        TestDefaite(&pcm[0],key,score);
        ChangementDirPacman(&pcm[0],key,score);

        val3++;
        *score=CompteurScore(score,&pcm[0],diamants);
        AffichageScore(score);
        if (*score==150*((diamants[0]).nombreDeDiamants/5))
        {
            Reinitialisation(&pcm[0],ennemi,diamants,tab,score,&key);
            lvl4(key, temps, score,pcm, ennemi, diamants,tab, murOnOff,Yukunkun);
        }
    }
}

void lvl2(char *key, unsigned long int *temps, int *score, Pcman pcm[100], Pcman ennemi[4], Objet diamants[100], int tab[20][50], int murOnOff, Objet *Yukunkun)
{
    int val1=0, val2 = 0, val3 = 0;
    if (*score>=100*((diamants[0]).nombreDeDiamants/5))
    {
        system("cls");
        lvl3(key, temps,score,&pcm[0], ennemi, diamants,tab, murOnOff,Yukunkun);
    }
    system("cls");

    initialisationEnnemi(ennemi); //Initialise les
    CreationContour(tab, murOnOff);
    // Creation du niveau
    GenerationAleatoireDePcman(&pcm[0]);
    GenerationAleatoireDePcman(&ennemi[0]);
    GenerationAleatoireDePcman(&ennemi[1]);
    GenerationAleatoireDePcman(&ennemi[2]);
    GenerationAleatoireDePcman(&ennemi[3]);
    *score = 50*((diamants[0]).nombreDeDiamants/5);
    AffichagePacman(&pcm[0]);
    GenerationAleatoireDeDiamants(diamants);
    while (*key!='n')
    {
        val2 = 1- val2;
        Sleep(*temps);

        if(val3>=5-(*pcm).vitesse)
        {

            VieAutonome(&pcm[0], diamants,score,tab,ennemi, murOnOff);
            val3=0;
        }

        if(val2==0)
        {
            val1 = 1 - val1;

            if(val1 == 0)
            {
                VieAutonomeEnnemie(&ennemi[0],tab,diamants,&pcm[0], murOnOff,Yukunkun);
                VieAutonomeEnnemie(&ennemi[1],tab,diamants,&pcm[0], murOnOff,Yukunkun);
                VieAutonomeEnnemie(&ennemi[2],tab,diamants,&pcm[0], murOnOff,Yukunkun);      // ces 2 vont moins vite que les 2 autres ennemis
                VieAutonomeEnnemie(&ennemi[3],tab,diamants,&pcm[0], murOnOff,Yukunkun);
            }
        }

        TestDefaite(&pcm[0],key,score);
        ChangementDirPacman(&pcm[0],key,score);

        val3++;
        TestDefaite(&pcm[0],key,score);
        ChangementDirPacman(&pcm[0],key,score);
        *score=CompteurScore(score,&pcm[0],diamants);
        AffichageScore(score);
        if (*score==100*((diamants[0]).nombreDeDiamants/5))
        {
            system("cls");
            lvl3(key, temps, score,&pcm[0], ennemi, diamants,tab, murOnOff,Yukunkun);
        }
    }
}

void lvl1(char *key, unsigned long int *temps, int *score, Pcman pcm[100], Pcman ennemi[4], Objet diamants[100], int tab[20][50], int murOnOff, Objet *Yukunkun)
{
    int val3 = 0;
    if (*score>=50*(diamants[0]).nombreDeDiamants/5)
    {
        system("cls");
        lvl2(key, temps,score,pcm, ennemi, diamants,tab,murOnOff,Yukunkun);
    }
    system("cls");
    InitialisationPerso(&pcm[0]);
    InitialisationObjet(diamants); //Initialise les
    CreationContour(tab, murOnOff);// Creation du niveau
    GenerationAleatoireDePcman(&pcm[0]);
    AffichagePacman(pcm);
    GenerationAleatoireDeDiamants(diamants);
    *score = 0;
    while (*key!='n')
    {
        Sleep(*temps);
        if(val3>=5-(*pcm).vitesse)
        {

            VieAutonome(&pcm[0], diamants,score,tab,ennemi, murOnOff);
            val3=0;
        }
        val3++;
        ChangementDirPacman(&pcm[0], key, score);
        *score=CompteurScore(score,&pcm[0],diamants);
        AffichageScore(score);
        if (*score==50*((diamants[0]).nombreDeDiamants/5))
        {
            system("cls");
            lvl2(key, temps, score,&pcm[0], ennemi, diamants,tab, murOnOff,Yukunkun);
        }
        TestDefaite(&pcm[0],key,score);

    }
}


