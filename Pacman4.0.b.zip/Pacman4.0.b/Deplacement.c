#include <stdio.h>
#include <stdlib.h>
#include "main.h"
#include <windows.h>
#include <time.h>
#include "ListeFonctions.h"
// DEPLACEMENT

void Deplacement(Pcman *pcm)   // Deplace le personnage sur le terrain
{
    switch((*pcm).direction)
    {
    case 'd':
        // On actualise la position ant�rieur du Pacman
        (*pcm).coordonneXv=(*pcm).coordonneX;
        (*pcm).coordonneYv=(*pcm).coordonneY;

        (*pcm).coordonneX+=1;  //Deplacement vers la droite
        break;
    case 'q':
        // On actualise la position ant�rieur du Pacman
        (*pcm).coordonneXv=(*pcm).coordonneX;
        (*pcm).coordonneYv=(*pcm).coordonneY;

        (*pcm).coordonneX-=1;   // Deplacement vers la gauche
        break;
    case 'z':
        // On actualise la position ant�rieur du Pacman
        (*pcm).coordonneXv=(*pcm).coordonneX;
        (*pcm).coordonneYv=(*pcm).coordonneY;
        // On actualise la position ant�rieur du Pacman
        (*pcm).coordonneY-=1;   //Deplacement vers le haut
        break;
    case 's':
        // On actualise la position ant�rieur du Pacman
        (*pcm).coordonneXv=(*pcm).coordonneX;
        (*pcm).coordonneYv=(*pcm).coordonneY;

        (*pcm).coordonneY+=1;    //Deplacement vers le bas
        break;
    }
}
void DeplacementSnake(Pcman snake[100], int jsp) // Deplace les maillons du snakes
{
    // On actualise la position ant�rieur du maillon
    snake[jsp].coordonneXv=snake[jsp].coordonneX;
    snake[jsp].coordonneYv=snake[jsp].coordonneY;
    // On lui donne la position ant�rieur du maillon avant lui
    snake[jsp].coordonneX=snake[jsp-1].coordonneXv;
    snake[jsp].coordonneY=snake[jsp-1].coordonneYv;
}
void Blocage(Pcman *pcm)    //Bloque le deplacement du personnage
{
    switch((*pcm).direction)
    {
    case 'd':
        (*pcm).coordonneX-=1;  // Bloque le deplacement � droite
        break;
    case 'q':
        (*pcm).coordonneX+=1;  // Bloque le deplacement � gauche
        break;
    case 'z':
        (*pcm).coordonneY+=1;  // Bloque le deplacement en haut
        break;
    case 's':
        (*pcm).coordonneY-=1;   // Bloque le deplacement en bas
        break;
    }
}
void Rebond(Pcman *pcm)    //Bloque le deplacement du personnage
{
    switch((*pcm).direction)
    {
    case 'd':
        (*pcm).coordonneX-=1;  // Bloque le deplacement � droite
        (*pcm).direction='q';  // On lui donne la direction oppos�e
        break;
    case 'q':
        (*pcm).coordonneX+=1;  // Bloque le deplacement � gauche
        (*pcm).direction='d';  // On lui donne la direction oppos�e
        break;
    case 'z':
        (*pcm).coordonneY+=1;  // Bloque le deplacement en haut
        (*pcm).direction='s';  // On lui donne la direction oppos�e
        break;
    case 's':
        (*pcm).coordonneY-=1;   // Bloque le deplacement en bas
        (*pcm).direction='z';  // On lui donne la direction oppos�e
        break;
    }
}
void Reapparition(Pcman *pcm)  // Fait r�aparaitre le personnage de l'autre c�t� lorque il passe une bordure
{
    switch((*pcm).direction)
    {
        case 'd':
            (*pcm).coordonneX=1;  // Reapparait � gauche
            break;
        case 'q':
            (*pcm).coordonneX=48;  // Reapparait � droite
            break;
        case 'z':
            (*pcm).coordonneY=19;  // Reapparait en haut
            break;
        case 's':
            (*pcm).coordonneY=1;   // Reapparait en bas
            break;
    }
}
void Teleporter(Pcman *pcm)
{
    int val=0;
    SetConsoleTextAttribute(GetStdHandle(STD_OUTPUT_HANDLE), 95);
    gotoligcol(4+12,10+60);
    printf(" ");
    gotoligcol(17+12,40+60);
    printf(" ");

    if((pcm->coordonneY==4) && (pcm->coordonneX==10))
        val = 1;

    if((pcm->coordonneY==17) && (pcm->coordonneX==40))
        val = 2;

    switch(val)
    {
    case 1 :
        pcm->coordonneY=17;
        pcm->coordonneX=40;
        break;
    case 2 :
        pcm->coordonneY=4;
        pcm->coordonneX=10;
        break;
    }

    SetConsoleTextAttribute(GetStdHandle(STD_OUTPUT_HANDLE), 15);
}
void ChangementDirPacman(Pcman *pcm, char *key, int *score) //Donne une nouvelle direction au pacman en fonction de la touche appuy� par l'utilisateur
{
    if(kbhit())
    {
        *key=getch();
        switch(*key)
        {
        case 'd':
            (*pcm).direction='d';
            break;
        case 'q':
            (*pcm).direction='q';
            break;
        case 'z':
            (*pcm).direction='z';
            break;
        case 's':
            (*pcm).direction='s';
            break;
        case 'h':
            SauvegardeNiveau(score);
            break;
        case 'p':     // Mets la parte en pause si l'utilisateur presse la touche p
            gotoligcol(26+12,60);
            printf("Appuyer sur n'importe quelle touche pour reprendre");
            *key=getch();
            gotoligcol(26+12,60);
            printf("                                                   ");
            break;
        case 'o':   // O comme out, permet de sortir de la partie
            *key='n';
            SauvegardeNiveau(score);
            break;
        }
    }

}
void changementDirEnnemie(Pcman *ennemi) // Donne une nouvelle direction al�atoire au fantme
{
    // DECLARATION DES VARIABLES //
    char tabd[4];
    int i;

    // On initalise le tableau e dirrection
    tabd[0]='s';
    tabd[1]='d';
    tabd[2]='q';
    tabd[3]='z';

    // On donne une direction al�atoire
    i=rand()%4;
    (*ennemi).direction=tabd[i];
}
void changementDirIntelligente(Pcman *pcm, Pcman *ennemi) // Donne la direction la plus proche du pacman au fant�me
{
    // DECLARATION DES VARIABLE //
    double tabDistance[4];
    char tabd[4];


    tabd[0]='d';
    tabd[1]='q';
    tabd[2]='s';
    tabd[3]='z';

    // TRAITEMENT //
    // On calcul la distance (norme eucldienne) des quatres futurs positions possibles des fantomes et du pacman
    tabDistance[0]= sqrt(pow((*pcm).coordonneX - ((*ennemi).coordonneX + 1),2) + pow((*pcm).coordonneY - ((*ennemi).coordonneY),2));
    tabDistance[1]= sqrt(pow((*pcm).coordonneX - ((*ennemi).coordonneX - 1),2) + pow((*pcm).coordonneY - ((*ennemi).coordonneY),2));
    tabDistance[2]= sqrt(pow((*pcm).coordonneX - ((*ennemi).coordonneX),2) + pow((*pcm).coordonneY - ((*ennemi).coordonneY + 1),2));
    tabDistance[3]= sqrt(pow((*pcm).coordonneX - ((*ennemi).coordonneX),2) + pow((*pcm).coordonneY - ((*ennemi).coordonneY - 1),2));

    // On donne au fantome la direction correspondant � la distance la plus faible
    (*ennemi).direction=tabd[MinTab(tabDistance,4)];
}

void ConditionChangementDir(Pcman *ennemi,Pcman *pcm) // Change la direction du fant�me tout les 5 mouvements (choix arbitraire)
{
    if ((*ennemi).compteurmvt ==5)
    {
        if ((*ennemi).IAON=='1') // On test si la I.A de l'ennemi est activ�
        {
            changementDirIntelligente(pcm,ennemi);
            (*ennemi).compteurmvt=0;
        }
        else
        {
            changementDirEnnemie(ennemi);
            (*ennemi).compteurmvt=0;
        }
    }
}


void AugmentationVitesse(Pcman *pcm) // Permet au pacman d'acc�l�rer
{
    if ((*pcm).vitesseON==1)  // On test si l'augmentation de vitesse est activ�
    {
        if((*pcm).vitesse<5)   //Si la vitesse ne d�passe pas d�j� 3, alors elle est incr�ment�e de 1
            (*pcm).vitesse+=1;
    }
}

void VieAutonome(Pcman *pcm, Objet diamants[100],int *score, int tab[20][50], Pcman ennemi[4], int murOnOff)// Deplace le pacman tout seul, et fait un peu pr�s tout aussi
{
    int i = 0;


        AffichageBlanc(pcm); // On efface le dernier positionnement
        Deplacement(pcm);    // On fait deplacer le personnage


        if (tab[(*pcm).coordonneY][(*pcm).coordonneX]=='1')  // On test si le d�placement � amen� � un mur
        {

            if (murOnOff==1)   // On test si le mode bordure est On
            {
                Blocage(pcm);   // On annule le deplacement du personnage
                AffichagePacman(pcm);  // On l'affiche
                PerteDePointDeVie(pcm); // On lui fait perdre un point de vie
            }
            else if (murOnOff!=1)  // si les bordure sont off
            {

                    Reapparition(pcm);  // On deplace le pac man de l'autre c�t�
                    AffichagePacman(pcm);  // On l'affiche
            }
        }
         else  if (tab[(*pcm).coordonneY][(*pcm).coordonneX]=='2')  // On test si le deplace�ent � amen� � un mur int�rieur
                {
                    Blocage(pcm);   // on annule le deplacement
                    AffichagePacman(pcm);  // on affiche le pacman
                }

        else   // Si il ne touche rien
        {
            boucleToucherCouler(pcm,ennemi); // On test si il touche un ennemi

            AffichagePointDeVie(pcm); // on affiche les points de vie
            AffichagePacman(pcm);  // On affiche le pacman
        }

}
void VieAutonomeSnake(Pcman *pcm,int tab[20][50], Pcman ennemi[4],  int jsp, Pcman snake[100])
{

        AffichageBlanc(pcm);
        DeplacementSnake(snake,jsp); // on deplace le maillon

        AffichagePacman(pcm);

}

void VieAutonomeEnnemie(Pcman *ennemi, int tab[20][50], Objet diamants[100],Pcman pcm[100], int murOnOff, Objet *Yukunkun)//////////////////////////////////////////////////
{

        ConditionChangementDir(ennemi, &pcm[0]); // on lance la possibilit� de changer de direction
        AffichageBlanc(ennemi);
        LesFantomesNeMangesPas(ennemi, diamants, Yukunkun);  // On empeche les fantomes de manger les diamants oule Yukunkun
        Deplacement(ennemi);

        if (tab[(*ennemi).coordonneY][(*ennemi).coordonneX]=='1')
        {

            if(murOnOff==1)
            {
                (*ennemi).compteurmvt+=1;
                Rebond(ennemi);

                AffichagePacman(ennemi);
                ConditionChangementDir(ennemi, pcm);
            }
            else if (murOnOff!=1)
            {
                (*ennemi).compteurmvt+=1;
                Reapparition(ennemi);
                AffichagePacman(ennemi);
                ConditionChangementDir(ennemi, pcm);
            }
        }
        else if (tab[(*ennemi).coordonneY][(*ennemi).coordonneX]=='2')
        {
            (*ennemi).compteurmvt+=1;
            Blocage(ennemi);
            AffichagePacman(ennemi);
        }
        else
        {
            ToucherCouler(&pcm[0],ennemi);
            ToucherCouper(pcm,ennemi);
            (*ennemi).compteurmvt+=1;
            AffichagePacman(ennemi);
        }


}

