



void pacmanAffichage();
void PremierEcran();
void menuOption();
void regles();

void bougerMenu(int i);
void afficherFleche(int i);

int modulo(int x,int N);


void lvl1(char *key, unsigned long int *temps, int *score, Pcman *pcm, Pcman ennemi[4], Objet diamants[5], int tab[20][50], int longueurTab,int largeurTab);
void lvl2(char *key, unsigned long int *temps, int *score, Pcman *pcm, Pcman ennemi[4], Objet diamants[5], int tab[20][50], int longueurTab,int largeurTab);
void lvl3(char *key, unsigned long int *temps, int *score, Pcman *pcm, Pcman ennemi[4], Objet diamants[5], int tab[20][50], int largeurTab,int longueurTab);




void modifVitesse(unsigned long int *temps, int i);
void choixVitesse(unsigned long int *temps, int i);
void ctrlVitesse();
