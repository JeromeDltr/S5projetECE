//Initialisations des attributs
void InitialisationPerso(Pcman *pcm);
void InitialisationObjet(Objet diamants[5]);
void initialisationEnnemi(Pcman ennemi[4]);
void InitialisationEnnemiIA(Pcman ennemi[4]);
void InitialisationVitesseON(Pcman *pcm, Pcman ennemi[4]);


//DEPLACEMENT
void AvancementX(Pcman *pcm);
void ReculX(Pcman *pcm);
void AvancementY(Pcman *pcm);
void ReculY(Pcman *pcm);

// BLOCAGE
void RetourX(Pcman *pcm);
void RetourY(Pcman *pcm);
void RetourXG(Pcman *pcm);
void RetourYH(Pcman *pcm);


