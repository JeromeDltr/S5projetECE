
#include <stdio.h>
#include <stdlib.h>
#include "main.h"
#include <windows.h>
#include <time.h>
#include "Fonction.h"
#include "deplacement.h"

void VieAutonome(Pcman *pcm,Pcman *point,int *score,int *Pomme, char tab[12][46])
{
   if ((*pcm).direction=='d')
   {
       AffichageBlanc(&(*pcm));
       AvancementX(&(*pcm));
       if (tab[(*pcm).coordonneY][(*pcm).coordonneX]=='*')
        {
            RetourX(pcm);
            AffichagePacman(&(*pcm));
            ActualisationCompteurMouvement(&(*pcm), Pomme);
            *Pomme=ActualisationPomme(&(*pcm),&(*point),Pomme);
        }

       else
        {
            *score=CompteurScore(score,&(*pcm),&(*point),Pomme,tab);
            *Pomme=ActualisationPomme(&(*pcm),&(*point),Pomme);
            AffichageScore(score);
            AffichagePacman(&(*pcm));
            ActualisationCompteurMouvement(&(*pcm), Pomme);
        }
   }

   if ((*pcm).direction=='s')
   {
         AffichageBlanc(&(*pcm));
         ReculY(&(*pcm));
         if (tab[(*pcm).coordonneY][(*pcm).coordonneX]=='*')
        {
            RetourY(pcm);
            AffichagePacman(&(*pcm));
            ActualisationCompteurMouvement(&(*pcm), Pomme);
            *Pomme=ActualisationPomme(&(*pcm),&(*point),Pomme);
        }

         else
        {
            *score=CompteurScore(score,&(*pcm),&(*point),Pomme,tab);
            *Pomme=ActualisationPomme(&(*pcm),&(*point),Pomme);
            AffichageScore(score);
            AffichagePacman(&(*pcm));
            ActualisationCompteurMouvement(&(*pcm), Pomme);
        }
   }

   if ((*pcm).direction=='z')
   {
         AffichageBlanc(&(*pcm));
         AvancementY(&(*pcm));

        if (tab[(*pcm).coordonneY][(*pcm).coordonneX]=='*')
        {
            RetourYH(pcm);
            AffichagePacman(&(*pcm));
            ActualisationCompteurMouvement(&(*pcm), Pomme);
            *Pomme=ActualisationPomme(&(*pcm),&(*point),Pomme);
        }

         else
        {
            *score=CompteurScore(score,&(*pcm),&(*point),Pomme,tab);
            *Pomme=ActualisationPomme(&(*pcm),&(*point),Pomme);
            AffichageScore(score);
            AffichagePacman(&(*pcm));
            ActualisationCompteurMouvement(&(*pcm), Pomme);
        }
   }

   if ((*pcm).direction=='q')
   {
         AffichageBlanc(&(*pcm));
         ReculX(&(*pcm));
         if (tab[(*pcm).coordonneY][(*pcm).coordonneX]=='*')
        {
            RetourXG(&(*pcm));
            AffichagePacman(&(*pcm));
            ActualisationCompteurMouvement(&(*pcm), Pomme);
            *Pomme=ActualisationPomme(&(*pcm),&(*point),Pomme);
        }

         else
        {
            *score=CompteurScore(score,&(*pcm),&(*point),Pomme,tab);
            *Pomme=ActualisationPomme(&(*pcm),&(*point),Pomme);
            AffichageScore(score);
            AffichagePacman(&(*pcm));
            ActualisationCompteurMouvement(&(*pcm), Pomme);
        }
   }
}
void VieAutonomeEnnemie(Pcman *pcm, char tab[12][46])
{
   if ((*pcm).direction=='d')
   {
         AffichageBlanc(&(*pcm));
         AvancementX(&(*pcm));
         if (tab[(*pcm).coordonneY][(*pcm).coordonneX]=='*')
        {
            RetourX(pcm);
            AffichagePacman(&(*pcm));
            (*pcm).compteurmvt+=1;
            ConditionChangementDir(pcm);
        }
         else
        {
            (*pcm).compteurmvt+=1;
            AffichagePacman(&(*pcm));
            ConditionChangementDir(pcm);
        }
   }

   if ((*pcm).direction=='s')
   {
        AffichageBlanc(&(*pcm));
        ReculY(&(*pcm));

        if (tab[(*pcm).coordonneY][(*pcm).coordonneX]=='*')
        {
            RetourY(pcm);
            AffichagePacman(&(*pcm));
            (*pcm).compteurmvt+=1;
            ConditionChangementDir(pcm);
        }
        else
        {
            (*pcm).compteurmvt+=1;
            AffichagePacman(&(*pcm));
            ConditionChangementDir(pcm);
        }
   }
   if ((*pcm).direction=='z')
   {
        AffichageBlanc(&(*pcm));
        AvancementY(&(*pcm));

        if (tab[(*pcm).coordonneY][(*pcm).coordonneX]=='*')
        {
            RetourYH(pcm);
            AffichagePacman(&(*pcm));
            (*pcm).compteurmvt+=1;
            ConditionChangementDir(pcm);
        }
        else
        {
            (*pcm).compteurmvt+=1;
            AffichagePacman(&(*pcm));
            ConditionChangementDir(pcm);
        }
   }

   if ((*pcm).direction=='q')
   {
      AffichageBlanc(&(*pcm));
      ReculX(&(*pcm));

      if (tab[(*pcm).coordonneY][(*pcm).coordonneX]=='*')
        {
            RetourXG(pcm);
            AffichageBlanc(&(*pcm));
            AffichagePacman(&(*pcm));
            (*pcm).compteurmvt+=1;
            ConditionChangementDir(pcm);
        }

      else
        {
            AffichagePacman(&(*pcm));
            (*pcm).compteurmvt+=1;
            ConditionChangementDir(pcm);
        }
   }
}

void changementDirEnnemie(Pcman *pcm)
{
    char tabd[4];
    int i;
    tabd[0]='s';
    tabd[1]='d';
    tabd[2]='q';
    tabd[3]='z';
    i=rand()%4;
    (*pcm).direction=tabd[i];
}

void ConditionChangementDir(Pcman *pcm)
{
    if ((*pcm).compteurmvt ==10)
    {
        changementDirEnnemie(pcm);
        (*pcm).compteurmvt=0;
    }
}
