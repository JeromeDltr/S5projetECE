void gotoligcol(int lig, int col);
void AffichagePacman(Pcman *pcm);
void AffichageBlanc(Pcman *pcm);
void creationNiveau(char tab[12][46],int *scoreF, Pcman *ennemi);
void GenerationAleatoireObjet(int largeurTab,int LongueurTab, Pcman *point,char tab[12][46]);
void AffichageScore(int *score);
int CompteurScore(int *score, Pcman *pcm, Pcman *point, int *Pomme,char tab[12][46]);
int ActualisationPomme(Pcman *pcm, Pcman *point, int *Pomme);
void MORT(Pcman *pcm,Pcman *ennemi,char *key);
