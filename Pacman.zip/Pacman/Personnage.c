#include <stdio.h>
#include <stdlib.h>
#include "main.h"
#include <windows.h>
#include <time.h>

// INITIALISATION DES PARAMETRES
void InitialisationPerso(Pcman *pcm, Pcman *point, Pcman *ennemi)
{
  (*pcm).nom='X';
  (*pcm).coordonneX=2;
  (*pcm).coordonneY=1;
  (*pcm).compteurmvt=0;
  (*pcm).direction='d';

  (*point).nom='O';
  (*point).coordonneX=0;
  (*point).coordonneY=0;
  (*point).compteurmvt=0;

  (ennemi[0]).nom='E';
  (ennemi[0]).coordonneX=3;
  (ennemi[0]).coordonneY=3;
  (ennemi[0]).compteurmvt=0;
  (ennemi[0]).direction='d';

  (ennemi[1]).nom='E';
  (ennemi[1]).coordonneX=5;
  (ennemi[1]).coordonneY=5;
  (ennemi[1]).compteurmvt=0;
  (ennemi[1]).direction='d';

  (ennemi[2]).nom='E';
  (ennemi[2]).coordonneX=7;
  (ennemi[2]).coordonneY=7;
  (ennemi[2]).compteurmvt=0;
  (ennemi[2]).direction='d';
}

// DEPLACEMENT
void AvancementX(Pcman *pcm)
{
    (*pcm).coordonneX+=1;
}
void ReculX(Pcman *pcm)
{
    (*pcm).coordonneX-=1;
}
void AvancementY(Pcman *pcm)
{
    (*pcm).coordonneY-=1;
}
void ReculY(Pcman *pcm)
{
    (*pcm).coordonneY+=1;
}

void RetourX(Pcman *pcm)
{
    (*pcm).coordonneX-=1;
}
void RetourXG(Pcman *pcm)
{
    (*pcm).coordonneX+=1;
}
void RetourY(Pcman *pcm)
{

    (*pcm).coordonneY-=1;
}
void RetourYH(Pcman *pcm)
{

    (*pcm).coordonneY+=1;
}

//

int ActualisationCompteurMouvement(Pcman *pcm,int *Pomme)
{
    if (*Pomme==1)
    {
        (*pcm).compteurmvt+=1;
    }
}
