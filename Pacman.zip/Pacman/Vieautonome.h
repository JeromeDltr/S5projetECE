#ifndef Vieautonome
#define Vieautonome
void VieAutonome(Pcman *pcmn,Pcman *point, int *score, int *Pomme, char tab[12][46]);
void VieAutonomeEnnemie(Pcman *pcm, char tab[12][46]);
void changementDirEnnemie(Pcman *pcm);
void ConditionChangementDir(Pcman *pcm);
#endif
