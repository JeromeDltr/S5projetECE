#include <stdio.h>
#include <stdlib.h>
#include "main.h"
#include <windows.h>
#include <time.h>
#include "deplacement.h"
void gotoligcol(int lig, int col)
{
    COORD mycoord;
    mycoord.X =col;
    mycoord.Y = lig;

    SetConsoleCursorPosition(GetStdHandle(STD_OUTPUT_HANDLE), mycoord);
}
void AffichagePacman(Pcman *pcm)
{


    gotoligcol((*pcm).coordonneY,(*pcm).coordonneX);
    printf("%c",(*pcm).nom);
}


void AffichageBlanc(Pcman *pcm)
{
    gotoligcol((*pcm).coordonneY,(*pcm).coordonneX);
    printf(" ");
}

void creationNiveau(char tab[12][46], int *scoreF, Pcman *ennemie)
{

    FILE *fic=NULL;
    int val,x=0,y=0,i=0;
    fic=fopen("C:\\Users\\Hussonnois Maxence\\Desktop\\Infos5\\Pacman\\niveau.txt","r");
         if (fic != NULL)
        {

            do
            {
                val = fgetc(fic);
                switch(val)
                {
                case 'B':

                    tab[y][x]='*';

                    gotoligcol(y,x);
                    printf("*");
                    x++;
                    break;
                case 'e':

                    tab[y][x]=' ';
                    (ennemie[i]).coordonneX=x;
                    (ennemie[i]).coordonneY=y;
                    gotoligcol(y,x);
                    i++;
                    printf("*");
                    x++;
                    break;
                case 'a':
                    tab[y][x]='.';

                    *scoreF+=1;
                    gotoligcol(y,x);
                    printf(".");
                    x++;
                    break;
                case 'm':
                    tab[y][x]='*';


                    gotoligcol(y,x);
                    printf("*");
                    x++;
                    break;
                case ' ':
                    tab[y][x]=' ';

                    gotoligcol(y,x);
                    printf(" ");
                    x++;
                    break;
                case 'p':
                     tab[y][x]='*';
                     gotoligcol(y,x);
                     printf("*");
                     printf("\n");
                     x=1;
                     y++;
                     break;
                } // On lit le caract�re
                 // On l'affiche
            } while (val != EOF);
        }
}

void GenerationAleatoireObjet(int largeurTab,int LongueurTab,Pcman *point, char tab[12][46])
{
    (*point).coordonneX=rand()%(largeurTab-1) +1;
    (*point).coordonneY=rand()%(LongueurTab-1) +1;


    while (tab[(*point).coordonneY][(*point).coordonneX]=='*')
    {
        (*point).coordonneX=rand()%(largeurTab-1) +1;
        (*point).coordonneY=rand()%(LongueurTab-1) +1;

    }
    gotoligcol((*point).coordonneY,(*point).coordonneX);
    printf("%c",(*point).nom);

}

int ActualisationPomme(Pcman *pcm, Pcman *point, int *Pomme)
{
    if (((*pcm).coordonneY==(*point).coordonneY) && ((*pcm).coordonneX==(*point).coordonneX))
    {
        *Pomme=1;
    }

    return *Pomme;
}


void AffichageScore(int *score)
{
    gotoligcol(15,0);
    printf("");
    printf("Le score est de %d",*score);
}
int CompteurScore(int *score, Pcman *pcm, Pcman *point, int *Pomme,char tab[12][46])

{

    if (tab[(*pcm).coordonneY][(*pcm).coordonneX]=='.')
    {
        *score+=1;

        tab[(*pcm).coordonneY][(*pcm).coordonneX]=' ';

    }

    return *score;
}

void MORT(Pcman *pcm,Pcman *ennemi,char *key)
{
    if (((*pcm).coordonneY==(*ennemi).coordonneY) && ((*pcm).coordonneX==(*ennemi).coordonneX))
     {
         *key='n';
         gotoligcol(14,0);
         printf("   T'ES MORT  ");
     }
}
