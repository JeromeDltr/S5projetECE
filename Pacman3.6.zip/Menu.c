#include <stdio.h>
#include <stdlib.h>
#include "main.h"
#include <time.h>
#include <windows.h>
#include "conio.h"
#include "ListeFonctions.h"

void afficherFleche(int indiceFleche)
{

    gotoligcol(indiceFleche+3+12,65);
    printf("->");
}

void pacmanAffichage()
{
    /*for(int i = 0; i<205; i++)
    {

    SetConsoleTextAttribute(GetStdHandle(STD_OUTPUT_HANDLE), i);
    printf("Text Color %d\n", i);
    //printf("#");
    }*/

    SetConsoleTextAttribute(GetStdHandle(STD_OUTPUT_HANDLE), 12);

    gotoligcol(0+12, 50);
    printf("         _______  _______  _______  _______  _______  _       ");
    gotoligcol(1+12, 50);
    printf("        (  ____ )(  ___  )(  ____ \\(       )(  ___  )( (    /|");
    gotoligcol(2+12, 50);
    printf("        | (    )|| (   ) || (    \\/| () () || (   ) ||  \\  ( |");
    gotoligcol(3+12, 50);
    printf("        | (____)|| (___) || |      | || || || (___) ||   \\ | |");
    gotoligcol(4+12, 50);
    printf("        |  _____)|  ___  || |      | |(_)| ||  ___  || (\\ \\) |");
    gotoligcol(5+12, 50);
    printf("        | (      | (   ) || |      | |   | || (   ) || | \\   |");
    gotoligcol(6+12, 50);
    printf("        | )      | )   ( || (____/\\| )   ( || )   ( || )  \\  |");
    gotoligcol(7+12, 50);
    printf("        |/       |/     \\|(_______/|/     \\||/     \\||/    )_| ");
    SetConsoleTextAttribute(GetStdHandle(STD_OUTPUT_HANDLE), 15);
}

void AfficherVictoire()
{
    char key;
    system("cls");
    SetConsoleTextAttribute(GetStdHandle(STD_OUTPUT_HANDLE), 10);

    gotoligcol(0+12, 40);
    printf("      ##                   ##\n");
    gotoligcol(1+12, 40);
    printf("       #.#                 , #.#\n");
    gotoligcol(2+12, 40);
    printf("     ( #####               ######,\n");
    gotoligcol(3+12, 40);
    printf("    # #####/#             #(##### #\n");
    gotoligcol(4+12, 40);
    printf("    ######## ,           ( ########\n");
    gotoligcol(5+12, 40);
    printf("    ##########     /     ##########\n");
    gotoligcol(6+12, 40);
    printf("    #########(#   #(#   ###########\n");
    gotoligcol(7+12, 40);
    printf("     ##########\(/ ### /# #########\n");
    gotoligcol(8+12, 40);
    printf("      #########  #####  #########\n");
    gotoligcol(9+12, 40);
    printf("     #  #######  #####  #######  #\n");
    gotoligcol(10+12, 40);
    printf("     \(\(#  #### ## ### ## ####  ###     ####  ######  ########  #######   #### ########  ########   #### \n");
    gotoligcol(11+12, 40);
    printf("     # ##/ ## ####   #### ## ###        ##  ##    ##    ##    ##     ##   ##  ##     ## ##         #### \n");
    gotoligcol(12+12, 40);
    printf("        #.# (######,######\( #,#         ##  ##          ##    ##     ##   ##  ##     ## ##          ## \n");
    gotoligcol(13+12, 40);
    printf("          ####################          ##  ##          ##    ##     ##   ##  ########  ######   \n");
    gotoligcol(14+12, 40);
    printf("         ##/ # ##.   .## # *#(          ##  ##          ##    ##     ##   ##  ##   ##   ##      \n");
    gotoligcol(15+12, 40);
    printf("         ###  # ####### #  ##(          ##  ##    ##    ##    ##     ##   ##  ##    ##  ##         #### \n");
    gotoligcol(16+12, 40);
    printf("               # ##### #               ####  ######     ##     #######   #### ##     ## ########   #### \n");
    gotoligcol(17+12, 40);
    printf("                #####,#\n");
    gotoligcol(18+12, 40);
    printf("                  \(#\)\n");
    SetConsoleTextAttribute(GetStdHandle(STD_OUTPUT_HANDLE), 15);

    key=getch();
}
void AfficherDefaite()
{
    char key;
    system("cls");
    SetConsoleTextAttribute(GetStdHandle(STD_OUTPUT_HANDLE), 4);

    gotoligcol(10+12, 40);
    printf("########   ########  ########     ###     ####  ########  ########      #### \n");
    gotoligcol(11+12, 40);
    printf("##     ##  ##        ##          ## ##     ##      ##     ##            #### \n");
    gotoligcol(12+12, 40);
    printf("##     ##  ##        ##         ##   ##    ##      ##     ##             ## \n");
    gotoligcol(13+12, 40);
    printf("##     ##  #####     #####     ##     ##   ##      ##     #####     \n");
    gotoligcol(14+12, 40);
    printf("##     ##  ##        ##        #########   ##      ##     ##          \n");
    gotoligcol(15+12, 40);
    printf("##     ##  ##        ##        ##     ##   ##      ##     ##            #### \n");
    gotoligcol(16+12, 40);
    printf("########   ########  ##        ##     ##  ####     ##     ########      #### \n");
    SetConsoleTextAttribute(GetStdHandle(STD_OUTPUT_HANDLE), 15);

    key=getch();
}

void PremierEcran()
{
    char keys='a';
    pacmanAffichage();
    gotoligcol(10+12,70);
    printf("Par : ");
    SetConsoleTextAttribute(GetStdHandle(STD_OUTPUT_HANDLE), 240);
    printf("Maxence, Remi et Jerome");
    SetConsoleTextAttribute(GetStdHandle(STD_OUTPUT_HANDLE), 15);
    gotoligcol(15+12,72);
    printf("Appuyer pour continuer");

    keys=getch();
}
void regles()//explication des r�gles
{
    char keys='b';
    system("cls");
    gotoligcol(3+12,60);
    printf("Le PACMAN est un jeu classique dans lequel un personnage se deplace");
    gotoligcol(4+12,60);
    printf("dans un espace plus ou moins complexe pour manger des diamants.");
    gotoligcol(7+12,60);
    printf("Il peut aller dans 4 directions a l\'aide du clavier et doit eviter");
    gotoligcol(8+12,60);
    printf("de se faire attraper par des fantomes qui sillonnent l\'espace de jeu.");
    gotoligcol(10+12,60);
    printf("Les touches de deplacement sont ");
    SetConsoleTextAttribute(GetStdHandle(STD_OUTPUT_HANDLE), 12);
    printf("z,q,s,d.");
    SetConsoleTextAttribute(GetStdHandle(STD_OUTPUT_HANDLE), 15);
    gotoligcol(13+12,60);
    printf("Appuyer pour continuer");

    keys=getch();
}
void menuOption()
{
    system("cls");
    gotoligcol(3+12,70);
    printf("1. rules");
    gotoligcol(5+12,70);
    printf("2. reglage de la vitesse");
    gotoligcol(7+12,70);
    printf("3. Nouvelle Partie");
    gotoligcol(9+12,70);
    printf("4. Reprendre Partie");
    gotoligcol(11+12,70);
    printf("5. Bordure");
    gotoligcol(13+12,70);
    printf("6. Quitter");
    gotoligcol(16+12,70);
    printf("Appuyer sur e pour valider");
}
void bougerMenu(int indiceFleche)
{
    menuOption();
    afficherFleche((modulo(indiceFleche,12)));
}

void ctrlVitesse()//Sert � d�finir la vitesse du jeu
{
    system("cls");
    gotoligcol(3+12,70);
    printf("Lent");
    gotoligcol(5+12,70);
    printf("Modere ");
    gotoligcol(7+12,70);
    printf("Rapide");
    gotoligcol(10+12,70);
    printf("Appuyer sur e pour valider");
}

void modifVitesse(unsigned long int *temps, int indiceFleche)//Pour afficher la vitesse choisi dans le menu "vitesse"
{
    ctrlVitesse();
    afficherFleche(modulo(indiceFleche,6));
}

void choixVitesse(unsigned long int *temps, int indiceFleche)//pour choisir la vitesse du jeu
{
    char keys='b';
    char answer='b';
    afficherFleche(indiceFleche);
    while (keys!='m')
    {
        if(kbhit())
        {
            answer=getch();
            switch (answer)
            {
            case 'z':
                indiceFleche -= 2;
                modifVitesse(&temps,indiceFleche);
                break;
            case 's':
                indiceFleche += 2;
                modifVitesse(&temps,indiceFleche);
                break;
            case 'e':
                if (modulo(indiceFleche,6)==0)
                {
                    *temps = 90;
                    keys = 'm';
                }
                if (modulo(indiceFleche,6)==2)
                {
                    *temps = 50;
                    keys = 'm';
                }
                if (modulo(indiceFleche,6)== 4)
                {
                    *temps = 20;
                    keys ='m';
                }

            }
        }
    }
}

void SauvegardeNiveau(int *score)
{
    FILE* sauvegarde = NULL;

    sauvegarde = fopen("sauvegarde.txt", "w");
    if (sauvegarde != NULL)
    {
        fprintf(sauvegarde,"%c\n",*score);
    }
    else
    {
        printf("Impossible d'ouvrir le fichier sauvegarde :(");
    }
    fclose(sauvegarde);

}

void ReprendreNiveau(char *key, unsigned long int *temps, int *score, Pcman pcm[100], Pcman ennemi[4], Objet diamants[100], int tab[20][50], int murOnOff,Objet *Yukunkun, int*nombre)
{
    FILE* sauvegarde = NULL;

    sauvegarde = fopen("sauvegarde.txt", "r");
    if (sauvegarde != NULL)
    {
        *score = fgetc(sauvegarde);

    }
    else
    {
        printf("Aucune sauvegarde disponible!");
    }
    fclose(sauvegarde);

    system("cls");
    lvl1(key, temps, score,pcm, ennemi, diamants,tab, murOnOff,Yukunkun,nombre);
    Reinitialisation(&pcm,ennemi,diamants,tab,&score,&key,nombre);


}

void bougerOptionMur(int murOnOff,int indiceFleche)
{
    OptionMur(murOnOff);
    afficherFleche(modulo(indiceFleche,4));
}

void OptionMur()//Sert � d�finir la vitesse du jeu
{
    system("cls");
    gotoligcol(3+12,70);
    printf("On");
    gotoligcol(5+12,70);
    printf("Off");
}

void choixOptionMur(int*murOnOff, int indiceFleche)
{
    indiceFleche = 0;
    afficherFleche(indiceFleche);
    char keys = 'a';
    char key;
    while (keys!='v')
    {
        if(kbhit())
        {
            key=getch();
            switch(key)
            {
            case 'z':
                indiceFleche -=2;
                bougerOptionMur(*murOnOff,indiceFleche);
                break;
            case 's':
                indiceFleche +=2;
                bougerOptionMur(*murOnOff,indiceFleche);
                break;
            case 'e':
                if (modulo(indiceFleche,4) == 0)
                {
                    *murOnOff = 1;
                }
                if (modulo(indiceFleche,4) == 2)
                {
                    *murOnOff = 0;
                }
                keys ='v';
                break;
            }
        }
    }
}

void FinProgramme()
{
    system("cls");
    SetConsoleTextAttribute(GetStdHandle(STD_OUTPUT_HANDLE), 14);
    gotoligcol(10+12, 70);
    printf("Au revoir !");
    SetConsoleTextAttribute(GetStdHandle(STD_OUTPUT_HANDLE), 0);
}
void lvl4(char *key, unsigned long int *temps, int *score, Pcman pcm[100], Pcman ennemi[4], Objet diamants[100], int tab[20][50], int murOnOff, Objet *Yukunkun, int*nombre)
{
    int i=0;
    int randi;
    int val1 = 0, val2 = 0, val3 = 0;
    srand(time(NULL));
    system("cls");
    InitialisationSnake(pcm);
    InitialisationYukunkun(Yukunkun);

    CreationContour(tab, murOnOff);// Creation du niveau

    GenerationAleatoireDePcman(&pcm[0]);

    AffichagePacman(&pcm[0]);

    GenerationAleatoireDePcman(&ennemi[0]);
    GenerationAleatoireDePcman(&ennemi[1]);
    GenerationAleatoireDePcman(&ennemi[2]);
    GenerationAleatoireDePcman(&ennemi[3]);
    GenerationAleatoireDeDiamants(diamants,*nombre);


    while (*key!='n')
    {

        randi=rand()%80;
        Sleep(*temps);
        if(val3>=5-(*pcm).vitesse)
        {

            VieAutonome(&pcm[0], diamants,score,tab,ennemi, murOnOff);
            OnSeMordPas(pcm);
            for (i=1; i<(pcm)[0].nombreDeTete; i++)
            {

                VieAutonomeSnake(&pcm[i],tab,ennemi,i,pcm);
            }
            val3=0;
        }

        if(val2==0)
        {
            val1 = 1 - val1;

            if(val1 == 0)
            {
                VieAutonomeEnnemie(&ennemi[0],tab,diamants,&pcm[0], murOnOff,Yukunkun,*nombre);
                VieAutonomeEnnemie(&ennemi[1],tab,diamants,&pcm[0], murOnOff,Yukunkun,*nombre);
                VieAutonomeEnnemie(&ennemi[2],tab,diamants,&pcm[0], murOnOff,Yukunkun,*nombre);      // ces 2 vont moins vite que les 2 autres ennemis
                VieAutonomeEnnemie(&ennemi[3],tab,diamants,&pcm[0], murOnOff,Yukunkun,*nombre);
                ToucherTete(key, temps, score,pcm, ennemi, diamants,tab, murOnOff,Yukunkun,*nombre);
            }
        }


        val3++;
        *score=CompteurScoreSnake(score,diamants,pcm,Yukunkun,*nombre);
        AffichageScore(score);
        ChangementDirPacman(&pcm[0], key, score);

        if ((randi==7)&& (*Yukunkun).nombreDeYukunkun==1 )
        {
            GenerationAleatoireObjet(Yukunkun);
        }
        if ((*Yukunkun).nombreDeYukunkun!=1)
        {
            Duree(Yukunkun);
        }
        TestVictoirelvl4(diamants,key,nombre);
        TestDefaite(&pcm[0],key);
    }
}

void lvl3(char *key, unsigned long int *temps, int *score, Pcman pcm[100], Pcman ennemi[4], Objet diamants[100], int tab[20][50], int murOnOff, Objet *Yukunkun, int*nombre)
{
    int val1 = 0, val2 = 0, val3 = 0, val4 = 0;
    system("cls");
    if (*score>=150*(*nombre/5))
    {
        Reinitialisation(&pcm[0],ennemi,diamants,tab,score,key,*nombre);
        lvl4(key, temps, score,pcm, ennemi, diamants,tab, murOnOff,Yukunkun,nombre);
    }
    CreationContour(tab, murOnOff);
    GenerationNiveauAlea(tab);
    InitialisationEnnemiIA(ennemi);// Creation du niveau
    InitialisationVitesseON(&pcm[0], ennemi);
    GenerationAleatoireDePcman(&pcm[0]);
    GenerationAleatoireDePcman(&ennemi[0]);
    GenerationAleatoireDePcman(&ennemi[1]);
    GenerationAleatoireDePcman(&ennemi[2]);
    GenerationAleatoireDePcman(&ennemi[3]);

    AffichagePacman(pcm);
    GenerationAleatoireDeDiamants(diamants,*nombre);
    *score=100;
    while (*key!='n')
    {

        val4 = 1- val4;
        Sleep(*temps);

        if(val3>=5-(*pcm).vitesse)
        {

            VieAutonome(&pcm[0], diamants,score,tab,ennemi, murOnOff);
            val3=0;
        }

        if(val4==0)
        {
            val2 = 1- val2;
            if(val2==0)
            {
                val1 = 1 - val1;
                VieAutonomeEnnemie(&ennemi[0],tab,diamants,&pcm[0], murOnOff,Yukunkun,*nombre);
                VieAutonomeEnnemie(&ennemi[1],tab,diamants,&pcm[0], murOnOff,Yukunkun,*nombre);
                if(val1 == 0)
                {
                    VieAutonomeEnnemie(&ennemi[2],tab,diamants,&pcm[0], murOnOff,Yukunkun,*nombre);      // ces 2 vont moins vite que les 2 autres ennemis
                    VieAutonomeEnnemie(&ennemi[3],tab,diamants,&pcm[0], murOnOff,Yukunkun,*nombre);
                }
            }
        }


        TestDefaite(&pcm[0],key);
        ChangementDirPacman(&pcm[0],key,score);

        val3++;
        *score=CompteurScore(score,&pcm[0],diamants,*nombre);
        AffichageScore(score);
        if (*score==150*(*nombre/5))
        {
            Reinitialisation(&pcm[0],ennemi,diamants,tab,score,&key,*nombre);
            lvl4(key, temps, score,pcm, ennemi, diamants,tab, murOnOff,Yukunkun,nombre);
        }
    }
}

void lvl2(char *key, unsigned long int *temps, int *score, Pcman pcm[100], Pcman ennemi[4], Objet diamants[100], int tab[20][50], int murOnOff, Objet *Yukunkun, int*nombre)
{
    int val1=0, val2 = 0, val3 = 0;
    if (*score>=100*(*nombre/5))
    {
        system("cls");
        lvl3(key, temps,score,&pcm[0], ennemi, diamants,tab, murOnOff,Yukunkun,nombre);
    }
    system("cls");

    initialisationEnnemi(ennemi); //Initialise les
    CreationContour(tab, murOnOff);
    // Creation du niveau
    GenerationAleatoireDePcman(&pcm[0]);
    GenerationAleatoireDePcman(&ennemi[0]);
    GenerationAleatoireDePcman(&ennemi[1]);
    GenerationAleatoireDePcman(&ennemi[2]);
    GenerationAleatoireDePcman(&ennemi[3]);
    *score = 50;
    AffichagePacman(&pcm[0]);
    GenerationAleatoireDeDiamants(diamants,*nombre);
    while (*key!='n')
    {
        val2 = 1- val2;
        Sleep(*temps);

        if(val3>=5-(*pcm).vitesse)
        {

            VieAutonome(&pcm[0], diamants,score,tab,ennemi, murOnOff);
            val3=0;
        }

        if(val2==0)
        {
            val1 = 1 - val1;

            if(val1 == 0)
            {
                VieAutonomeEnnemie(&ennemi[0],tab,diamants,&pcm[0], murOnOff,Yukunkun,*nombre);
                VieAutonomeEnnemie(&ennemi[1],tab,diamants,&pcm[0], murOnOff,Yukunkun,*nombre);
                VieAutonomeEnnemie(&ennemi[2],tab,diamants,&pcm[0], murOnOff,Yukunkun,*nombre);      // ces 2 vont moins vite que les 2 autres ennemis
                VieAutonomeEnnemie(&ennemi[3],tab,diamants,&pcm[0], murOnOff,Yukunkun,*nombre);
            }
        }

        TestDefaite(&pcm[0],key);
        ChangementDirPacman(&pcm[0],key,score);

        val3++;
        TestDefaite(&pcm[0],key);
        ChangementDirPacman(&pcm[0],key,score);
        *score=CompteurScore(score,&pcm[0],diamants,*nombre);
        AffichageScore(score);
        if (*score==100*(*nombre/5))
        {
            system("cls");
            lvl3(key, temps, score,&pcm[0], ennemi, diamants,tab, murOnOff,Yukunkun,nombre);
        }
    }
}

void lvl1(char *key, unsigned long int *temps, int *score, Pcman pcm[100], Pcman ennemi[4], Objet diamants[100], int tab[20][50], int murOnOff, Objet *Yukunkun, int*nombre)
{
    int val3 = 0;
    if (*score>=50*(*nombre/5))
    {
        system("cls");
        lvl2(key, temps,score,pcm, ennemi, diamants,tab,murOnOff,Yukunkun,nombre);
    }
    system("cls");
    InitialisationPerso(&pcm[0]);
    InitialisationObjet(diamants,*nombre); //Initialise les
    CreationContour(tab, murOnOff);// Creation du niveau
    GenerationAleatoireDePcman(&pcm[0]);
    AffichagePacman(pcm);
    GenerationAleatoireDeDiamants(diamants,*nombre);
    *score = 0;
    while (*key!='n')
    {
        Sleep(*temps);
        if(val3>=5-(*pcm).vitesse)
        {

            VieAutonome(&pcm[0], diamants,score,tab,ennemi, murOnOff);
            val3=0;
        }
        val3++;
        ChangementDirPacman(&pcm[0], key, score);
        *score=CompteurScore(score,&pcm[0],diamants,*nombre);
        AffichageScore(score);
        if (*score==50*(*nombre/5))
        {
            system("cls");
            lvl2(key, temps, score,&pcm[0], ennemi, diamants,tab, murOnOff,Yukunkun,nombre);
        }
        TestDefaite(&pcm[0],key);

    }
}

