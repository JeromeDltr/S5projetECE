void ctrlSpeed(int *temps);
void rules();
void lvl1();
void lvl2();
void PremierEcran();
void MenuOption();
void lvl1(char *key, int *temps, int *score, Pcman *pcm, Pcman ennemi[4], Objet diamants[5], int tab[20][50], int longueurTab,int largeurTab);
void lvl2(char *key, int *temps, int *score, Pcman *pcm, Pcman ennemi[4], Objet diamants[5], int tab[20][50], int longueurTab,int largeurTab);
void lvl3(char *key, int *temps, int *score, Pcman *pcm, Pcman ennemi[4], Objet diamants[5], int tab[20][50], int largeurTab,int longueurTab);
