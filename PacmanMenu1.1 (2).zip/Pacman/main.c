#include <stdio.h>
#include <stdlib.h>
#include "main.h"
#include <time.h>
#include <windows.h>
#include "Personnage.h"
#include "Vieautonome.h"
#include "Plateau.h"
#include"Menu.h"



int main()
{
  // DECLARATION DES VARIABLES
  //Variables li�es � la cr�ation du tableau
  int largeurTab=50;
  int longueurTab=20;
  int tab[20][50]={0};

  int i=0;


 //Variables li�es au score
  int score=0;

//Variable de temps
  long temps=50;
//Variable de boucle infinie
  char keys='a';

//Creation des variables personnage
  Pcman pcm;
  Pcman ennemi[4];
  Objet diamants[5];

  srand(time(NULL));
  PremierEcran();
  MenuOption();

  while (keys!='n')
    {
         if(kbhit())
        {
            keys=getch();
            switch(keys)
            {
                case '1':
                    rules();
                    MenuOption();
                    break;
                case '2':
                    ctrlSpeed(&temps);
                    MenuOption();
                    break;
                case '3':
                     lvl1(&keys,&temps, &score, &pcm, ennemi, diamants, tab, largeurTab,longueurTab);
                     break;


            }
        }

    }

    return 0;
}
