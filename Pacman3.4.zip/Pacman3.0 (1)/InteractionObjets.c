#include <stdio.h>
#include <stdlib.h>
#include "main.h"
#include <windows.h>
#include <time.h>
#include "ListeFonctions.h"


int CompteurScore(int *score, Pcman *pcm, Objet diamants[5])  // Mets � jours le score
{
    int i=0;

    for (i=0; i<5; i++) // On boucle sur tout les diamants
    {
        if (((*pcm).coordonneY==(diamants[i]).coordonneY) && ((*pcm).coordonneX==(diamants[i]).coordonneX)) // On test si le pacman est � la m�me position qu'un diamant
        {
            // On enleve le diamant du terrain
            (diamants[i]).coordonneY=0;
            (diamants[i]).coordonneX=0;

            *score+=10; // On met � jour le score
            AugmentationVitesse(pcm); // On met � jour la vitesse
        }
    }

    return *score;
}

int CompteurScoreSnake(int *score, Objet diamants[5], Pcman pcm[100], Objet *Yukunkun)  // Mets � jours le score pour le tableau 6
{
    int i=0,j=0;

    for (i=0; i<5; i++)
    {
        if (((pcm[0]).coordonneY==(diamants[i]).coordonneY) && ((pcm[0]).coordonneX==(diamants[i]).coordonneX))
        {
            (diamants[i]).coordonneY=0;
            (diamants[i]).coordonneX=0;
            *score+=10;
            NouvelleTete(pcm);// On ajoute une t�te
        }
    }
    if (((pcm)[0].coordonneY==(*Yukunkun).coordonneY) && ((pcm)[0].coordonneX==(*Yukunkun).coordonneX))
    {
        (*Yukunkun).coordonneX=0;
        (*Yukunkun).coordonneY=0;
        (*Yukunkun).duree=60;

        (*Yukunkun).nombreDeYukunkun--; // On reduit le nombre de Yukunkun
        *score+=5;  // On met � jours le score
        for (j=0; j<5; j++) // On ajoute les 5 nouvelles t�tes
        {
            NouvelleTete(pcm);
        }
    }
    return *score;
}


void TestVictoirelvl4(Objet diamants[5],char *key)
{
    int i ;
    int compteur=0;
    for (i=0; i<5; i++)
    {
        if (((diamants[i]).coordonneY==0) && ((diamants[i]).coordonneX==0))
        {
            compteur++;
        }

    }
    if (compteur==5)
    {
        *key='n';
        AfficherVictoire();
    }
}
void TestDefaite(Pcman *pcm, char *key) // Retourne au menu si il y a d�faite
{
    if ((*pcm).pointDeVie<1) // Test si on a 0 point de vie
    {
        system("cls");
        *key='n'; //
    }

}
