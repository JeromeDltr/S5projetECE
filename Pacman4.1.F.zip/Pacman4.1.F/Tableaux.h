
void lvl3(char *key, unsigned long int *temps, int *score, Pcman pcm[100], Pcman ennemi[4], Objet diamants[100], int tab[20][50], int murOnOff,Objet *Yukunkun,int chrono);
void lvl2(char *key, unsigned long int *temps, int *score, Pcman pcm[100], Pcman ennemi[4], Objet diamants[100], int tab[20][50], int murOnOff,Objet *Yukunkun,int chrono);
void lvl1(char *key, unsigned long int *temps, int *score, Pcman pcm[100], Pcman ennemi[4], Objet diamants[100], int tab[20][50], int murOnOff,Objet *Yukunkun,int chrono);


void lvl4(char *key, unsigned long int *temps, int *score, Pcman pcm[100], Pcman ennemi[4], Objet diamants[100], int tab[20][50], int murOnOff,Objet *Yukunkun, int chrono);
void lvl5(char *key, unsigned long int *temps, int *score, Pcman pcm[100], Pcman ennemi[4], Objet diamants[5], int tab[20][50], int murOnOff, Objet *Yukunkun, int chrono);
