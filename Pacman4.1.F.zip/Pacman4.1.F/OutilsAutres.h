int MinTab(double tab[4], int tailleTab);
int modulo(int x,int N);
void gotoligcol(int lig, int col);


