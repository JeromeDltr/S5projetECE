#include "Block.h"

int main()
{
    t_block b1;
    char **table;
    int i;
    char *carac;

    srand(time(NULL));
    table = malloc(10*sizeof(char**));
    for(i = 0 ; i < 10 ; i++)
    {
        table[i] = malloc(16*sizeof(char));
        table[i] = NULL;
    }
    GenerateAddress();
    InitBlock(&b1);
    Display(&b1);

    return 0;
}
