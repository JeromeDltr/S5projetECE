#include "Block.h"


char* Catenate(t_block *b)  //char *addressSend, char *addressRec, unsigned int *sendAmount, char *prevHash
{
    char *pt;
    pt = malloc((65+17+17+10)*sizeof(char));
    strcpy(pt, b->fromAddress);
    strcat(pt, b->toAddress);
    sprintf(pt, "%s%d", pt, b->amount);
    strcat(pt, b->prevTabHash);
    return pt;
}

void InitBlock(t_block *b)
{
    char *str1;
    char *str2;
    char *str3;
    char *str4;
    int val1;

    str1 = malloc(17*sizeof(char));
    str2 = malloc(17*sizeof(char));
    str3 = malloc(65*sizeof(char));
    str4 = malloc(65*sizeof(char));

    strcpy(str1, "Helloo");    //gets(str1);
    strcpy(str2, "Helloy");
    strcpy(str3, "Hellot");
    strcpy(str4, "Helloi");
    val1 = 10;

    strcpy(b->fromAddress, str1);
    strcpy(b->toAddress, str2);
    strcpy(b->prevTabHash, str3);
    b->amount = val1;
    //struct block *ptPrev;
    //struct block *ptSuiv;

    str4 = Catenate(b);
    str4 = SHA256(str4);
    strcpy(b->tabHash, str4);    //puts(str4);
}

char* RandNumber()
{
    int value;
    char carac;
    value = rand()%3;
    if(value==1)
        carac = rand()%(122-97+1)+97;
    if(value==2)
        carac = rand()%(90-65+1)+65;
    if(value==0)
        carac = rand()%(57-48+1)+48;

    return carac;
}

void GenerateAddress()
{
    char **table=malloc(10*sizeof(char**));

    int i, j;
    char carac; //const char*
    char ch[500]; // c'est la m�thode pour l'allocation de string, tu prends une grosse chaine comme r�f�rence

   // carac = 'a';

    //ch= malloc(16*sizeof(char)); // Plut�t que d'en allou� une
    for(i = 0 ; i < 10 ; i++)
    {
        for( j = 0 ; j < 16 ; j++)//j = 1
        {
            carac=RandNumber();
            ch[j]=carac;  // pas de strcpy vu que tu ajoutes des char la, strcpy c'est pour des chaines de caract�res.
            //puts(&(table[i]));
            //strcat(ch, carac);
        }
        // J'ai juste mis �a pour v�rifier si �a marchait bien tu peux faire autrement
        table[i]=malloc(16*sizeof(char*));
        strcpy(table[i],ch);
        printf("\n %s",table[i]);
        //
        printf("\n");
    }
        free(ch);
    /*
    //*carac = RandNumber();
    //strcpy(table[(char)i], *carac);
    */
}

void Display(t_block *b)
{
    printf("From address: ");
    puts(b->fromAddress);
    printf("To address: ");
    puts(b->toAddress);
    printf("Amount: %d\n", b->amount);
    printf("Hash: ");
    puts(b->tabHash);
}
