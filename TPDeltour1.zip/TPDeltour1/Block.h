#ifndef BLOCK_H_INCLUDED
#define BLOCK_H_INCLUDED
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <time.h>

typedef struct block
{
   char fromAddress[17];
   char toAddress[17];
   unsigned int amount;
   char tabHash[65];
   char prevTabHash[65];
   struct block *ptPrev;
   struct block *ptNext;
}t_block;

typedef struct blockchain
{
   t_block *ptGen;
   t_block *ptLast;
   int nbBlock;
   int nbAddress;
   char *listChar;
}t_blockchain;

char* Catenate(t_block *b);
void InitBlock(t_block *b);
void Display(t_block *b);
char* RandNumber();
void GenerateAddress();

#endif // BLOCK_H_INCLUDED
