void Teleporter(Pcman *pcm);
void changementDirEnnemie(Pcman *pcm);
void ConditionChangementDir(Pcman *pcm, Pcman *ennemi);
void changementDirIntelligente(Pcman *pcm, Pcman *ennemi);
void ChangementDirPacman(Pcman *pcm, char *key, int *score);

void VieAutonome(Pcman *pcmn,Objet diamants[100], int *score, int tab[20][50],Pcman ennemi[4], int murOnOff);
void VieAutonomeEnnemie(Pcman *ennemi, int tab[20][50], Objet diamants [100], Pcman *pcm, int murOnOff,Objet *Yukunkun);


void DeplacementSnake(Pcman pcm[100], int jsp);
void VieAutonomeSnake(Pcman *pcms,int tab[20][50], Pcman ennemi[4],int jsp, Pcman pcm[100]);
