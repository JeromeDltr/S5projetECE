#include <stdio.h>
#include <stdlib.h>
#include "main.h"
#include <time.h>
#include <windows.h>
#include "conio.h"
#include "OutilsAutres.h"
#include "Deplacement.h"
#include "InitialisationPers.h"
#include "InteractionObjets.h"
#include "InteractionPersonnages.h"
#include "Plateau.h"
#include "Tableaux.h"
#include <math.h>

void afficherFleche(int indiceFleche)//Affiche la fleche pour les diff�rents menu
{

    gotoligcol(indiceFleche+3+12,65);//Deplace la fleche suivant l'indice que l'utilisaeur lui donne
    printf("->");
}

void pacmanAffichage()//AFFICHAGE DU TITRE DU JEU
{
    /*for(int i = 0; i<205; i++)
    {

    SetConsoleTextAttribute(GetStdHandle(STD_OUTPUT_HANDLE), i);
    printf("Text Color %d\n", i);
    //printf("#");
    }*/

    SetConsoleTextAttribute(GetStdHandle(STD_OUTPUT_HANDLE), 12);

    gotoligcol(0+12, 50);
    printf("         _______  _______  _______  _______  _______  _       ");gotoligcol(1+12, 50);
    printf("        (  ____ )(  ___  )(  ____ \\(       )(  ___  )( (    /|");gotoligcol(2+12, 50);
    printf("        | (    )|| (   ) || (    \\/| () () || (   ) ||  \\  ( |");gotoligcol(3+12, 50);
    printf("        | (____)|| (___) || |      | || || || (___) ||   \\ | |");gotoligcol(4+12, 50);
    printf("        |  _____)|  ___  || |      | |(_)| ||  ___  || (\\ \\) |");gotoligcol(5+12, 50);
    printf("        | (      | (   ) || |      | |   | || (   ) || | \\   |");gotoligcol(6+12, 50);
    printf("        | )      | )   ( || (____/\\| )   ( || )   ( || )  \\  |");gotoligcol(7+12, 50);
    printf("        |/       |/     \\|(_______/|/     \\||/     \\||/    )_| ");
    SetConsoleTextAttribute(GetStdHandle(STD_OUTPUT_HANDLE), 15);
}

void AfficherVictoire()//Affichage en cas de win
{
    char key;
    system("cls");
    SetConsoleTextAttribute(GetStdHandle(STD_OUTPUT_HANDLE), 10);

    gotoligcol(0+12, 40);
    printf("      ##                   ##\n");gotoligcol(1+12, 40);
    printf("       #.#                 , #.#\n");gotoligcol(2+12, 40);
    printf("     ( #####               ######,\n");gotoligcol(3+12, 40);
    printf("    # #####/#             #(##### #\n");gotoligcol(4+12, 40);
    printf("    ######## ,           ( ########\n");gotoligcol(5+12, 40);
    printf("    ##########     /     ##########\n");gotoligcol(6+12, 40);
    printf("    #########(#   #(#   ###########\n");gotoligcol(7+12, 40);
    printf("     ##########\(/ ### /# #########\n");gotoligcol(8+12, 40);
    printf("      #########  #####  #########\n");gotoligcol(9+12, 40);
    printf("     #  #######  #####  #######  #\n");gotoligcol(10+12, 40);
    printf("     \(\(#  #### ## ### ## ####  ###     ####  ######  ########  #######   #### ########  ########   #### \n");gotoligcol(11+12, 40);
    printf("     # ##/ ## ####   #### ## ###        ##  ##    ##    ##    ##     ##   ##  ##     ## ##         #### \n");gotoligcol(12+12, 40);
    printf("        #.# (######,######\( #,#         ##  ##          ##    ##     ##   ##  ##     ## ##          ## \n");gotoligcol(13+12, 40);
    printf("          ####################          ##  ##          ##    ##     ##   ##  ########  ######   \n");gotoligcol(14+12, 40);
    printf("         ##/ # ##.   .## # *#(          ##  ##          ##    ##     ##   ##  ##   ##   ##      \n");gotoligcol(15+12, 40);
    printf("         ###  # ####### #  ##(          ##  ##    ##    ##    ##     ##   ##  ##    ##  ##         #### \n");gotoligcol(16+12, 40);
    printf("               # ##### #               ####  ######     ##     #######   #### ##     ## ########   #### \n");gotoligcol(17+12, 40);
    printf("                #####,#\n");gotoligcol(18+12, 40);
    printf("                  \(#\)\n");
    SetConsoleTextAttribute(GetStdHandle(STD_OUTPUT_HANDLE), 15);

    key=getch();
}

void AfficherDefaite()//Affichage en cas de lose
{
    char key;
    system("cls");
    SetConsoleTextAttribute(GetStdHandle(STD_OUTPUT_HANDLE), 4);

    gotoligcol(10+12, 40);
    printf("########   ########  ########     ###     ####  ########  ########      #### \n");
    gotoligcol(11+12, 40);
    printf("##     ##  ##        ##          ## ##     ##      ##     ##            #### \n");
    gotoligcol(12+12, 40);
    printf("##     ##  ##        ##         ##   ##    ##      ##     ##             ## \n");
    gotoligcol(13+12, 40);
    printf("##     ##  #####     #####     ##     ##   ##      ##     #####     \n");
    gotoligcol(14+12, 40);
    printf("##     ##  ##        ##        #########   ##      ##     ##          \n");
    gotoligcol(15+12, 40);
    printf("##     ##  ##        ##        ##     ##   ##      ##     ##            #### \n");
    gotoligcol(16+12, 40);
    printf("########   ########  ##        ##     ##  ####     ##     ########      #### \n");
    SetConsoleTextAttribute(GetStdHandle(STD_OUTPUT_HANDLE), 15);

    key=getch();
}

void PremierEcran()//AFFICHAGE DU PREMIER ECRAN
{
    char keys='a';
    pacmanAffichage();
    gotoligcol(10+12,70);
    printf("Par : ");
    SetConsoleTextAttribute(GetStdHandle(STD_OUTPUT_HANDLE), 240);
    printf("Maxence, Remi et Jerome");
    SetConsoleTextAttribute(GetStdHandle(STD_OUTPUT_HANDLE), 15);
    gotoligcol(15+12,72);
    printf("Appuyer pour continuer");

    keys=getch();
}
void regles()//explication des r�gles
{
    char keys='b';
    system("cls");
    gotoligcol(3+12,60);
    printf("Le PACMAN est un jeu classique dans lequel un personnage se deplace");
    gotoligcol(4+12,60);
    printf("dans un espace plus ou moins complexe pour manger des diamants.");
    gotoligcol(7+12,60);
    printf("Il peut aller dans 4 directions a l\'aide du clavier et doit eviter");
    gotoligcol(8+12,60);
    printf("de se faire attraper par des fantomes qui sillonnent l\'espace de jeu.");
    gotoligcol(10+12,60);
    printf("Les touches de deplacement sont ");
    SetConsoleTextAttribute(GetStdHandle(STD_OUTPUT_HANDLE), 12);
    printf("z,q,s,d.");
    SetConsoleTextAttribute(GetStdHandle(STD_OUTPUT_HANDLE), 15);
    gotoligcol(12+12,60);
    printf("Appuyer sur ");
    SetConsoleTextAttribute(GetStdHandle(STD_OUTPUT_HANDLE), 11);
    printf("P");
    SetConsoleTextAttribute(GetStdHandle(STD_OUTPUT_HANDLE), 15);
    printf(" pour faire pause pendant la partie.");
    gotoligcol(13+12,60);
    printf("Appuyer sur ");
    SetConsoleTextAttribute(GetStdHandle(STD_OUTPUT_HANDLE), 11);
    printf("O");
    SetConsoleTextAttribute(GetStdHandle(STD_OUTPUT_HANDLE), 15);
    printf(" pour quitter pendant la partie.");
    gotoligcol(16+12,60);
    printf("Appuyer pour continuer");

    keys=getch();
}
void menuOption()//iNTERFACE Menu principal
{
    system("cls");
    gotoligcol(3+12,70);
    printf("1. rules");gotoligcol(5+12,70);
    printf("2. reglage de la vitesse");gotoligcol(7+12,70);
    printf("3. Nouvelle Partie");gotoligcol(9+12,70);
    printf("4. Reprendre Partie");gotoligcol(11+12,70);
    printf("5. Bordure");gotoligcol(13+12,70);
    printf("6. Chronometre");gotoligcol(15+12,70);
    printf("7. Quitter");gotoligcol(18+12,70);
    printf("Appuyer sur e pour valider");
}
void bougerMenu(int indiceFleche) //Bouger la fleche dans le menu principal
{
    menuOption();
    afficherFleche((modulo(indiceFleche,14)));
}

void ctrlVitesse()//Sert � afficher les vitesses du jeu possible
{
    system("cls");
    gotoligcol(3+12,70);
    printf("Lent");gotoligcol(5+12,70);
    printf("Modere ");gotoligcol(7+12,70);
    printf("Rapide");gotoligcol(10+12,70);
    printf("Appuyer sur e pour valider");
}

void modifVitesse(unsigned long int *temps, int indiceFleche)//Pour afficher la vitesse choisi dans le menu "vitesse"
{
    ctrlVitesse();
    afficherFleche(modulo(indiceFleche,6));
}

void choixVitesse(unsigned long int *temps, int indiceFleche)//pour choisir la vitesse du jeu
{
    //INITIALISATION
    char keys='b';
    char answer='b';
    afficherFleche(indiceFleche);
    //TANT QUE L'UTILISATEUR N'AS PAS CHOISI UNE VALEUR
    while (keys!='m')
    {
        if(kbhit())
        {
            // ON RECUPERE LA TOUCHE SUR LAQUELLE IL APPUYE
            answer=getch();
            switch (answer)
            {
                //ON MODIFIE L EMPLACEMENT DU CURSEUR A L'ECRAN
            case 'z':
                indiceFleche -= 2;
                modifVitesse(&temps,indiceFleche);
                break;
            case 's':
                indiceFleche += 2;
                modifVitesse(&temps,indiceFleche);
                break;
            case 'e':
                //ON VERIFIE L'EMPLACEMENT DUR CURSEUR ET ON MODIFIE LA VARIABLE QUI CONTROLE LA VITESSE
                if (modulo(indiceFleche,6)==0)
                {
                    *temps = 90;
                    keys = 'm';
                }
                if (modulo(indiceFleche,6)==2)
                {
                    *temps = 50;
                    keys = 'm';
                }
                if (modulo(indiceFleche,6)== 4)
                {
                    *temps = 20;
                    keys ='m';
                }

            }
        }
    }
}

void SauvegardeNiveau(int *score)//Sauvegarder le score actuel dans un fichier texte
{
    FILE* sauvegarde = NULL;
    //ON OUVRE UN FICHIER
    sauvegarde = fopen("sauvegarde.txt", "w");
    if (sauvegarde != NULL)
    {
        fprintf(sauvegarde,"%d\n",*score);//ON ECRIT LE SCORE SI LE FICHIER EXISTE
    }
    else
    {
        //ON AFFICHE L'ERREUR SINON
        printf("Impossible d'ouvrir le fichier sauvegarde :(");
    }
    fclose(sauvegarde);//ON FERME LE FICHIER

}

void ReprendreNiveau(char *key, unsigned long int *temps, int *score, Pcman pcm[100], Pcman ennemi[4], Objet diamants[100], int tab[20][50], int murOnOff,Objet *Yukunkun, int chrono) //Relancer une partie en se basant sur le fichier de sauvegarde
{
    FILE* sauvegarde = NULL;
    char entier[10];
    *score = 0;


    sauvegarde = fopen("sauvegarde.txt", "r");
    if (sauvegarde != NULL)
    {
        fgets(entier,10,sauvegarde);//On lit la premiere ligne du fichier de sauvegarde
        (*score) = atoi(entier);//On recupere le chiffre qui correspond au score sauvegarde
    }
    else
    {
        printf("Aucune sauvegarde disponible!");
    }
    fclose(sauvegarde);

    system("cls");
    InitialisationTemps(&pcm[0],temps);
    lvl1(key, temps, score, pcm, ennemi, diamants,tab, murOnOff,Yukunkun,chrono);//ON RECHERCHE LE TABLEAU CORRESPONDANT A CE SCORE



}

void bougerOptionMur(int murOnOff,int indiceFleche)//Bouger la fleche dans les options du mur
{
    OptionMur(murOnOff);
    afficherFleche(modulo(indiceFleche,4));
}

void OptionMur()//Sert � d�finir la presence de mur
{
    system("cls");
    gotoligcol(3+12,70);
    printf("On");gotoligcol(5+12,70);
    printf("Off");
}

void choixOptionMur(int*murOnOff, int indiceFleche) // Defini si il y a pr�sence de mur ou non
{
    indiceFleche = 0;
    afficherFleche(indiceFleche);
    char keys = 'a';
    char key;
    while (keys!='v')
    {
        if(kbhit())
        {
            key=getch();
            switch(key)
            {
            case 'z':
                indiceFleche -=2;
                bougerOptionMur(*murOnOff,indiceFleche);
                break;
            case 's':
                indiceFleche +=2;
                bougerOptionMur(*murOnOff,indiceFleche);
                break;
            case 'e':
                if (modulo(indiceFleche,4) == 0)
                {
                    *murOnOff = 1;
                }
                if (modulo(indiceFleche,4) == 2)
                {
                    *murOnOff = 0;
                }
                keys ='v';
                break;
            }
        }
    }
}

void bougerOptionChrono(int chrono,int indiceFleche)
{
    OptionChrono();
    afficherFleche(modulo(indiceFleche,4));
}
void OptionChrono()
{
    system("cls");
    gotoligcol(3+12,70);
    printf("On");gotoligcol(5+12,70);
    printf("Off");
}
void ChoixOptionChrono(int*chrono, int indiceFleche)
{
    //INITIALISATION DES VARIABLES
    indiceFleche = 0;
    afficherFleche(indiceFleche);
    char keys = 'a';
    char key;
    //TRAITEMENT
    while (keys!='v')
    {
        if(kbhit())
        {
            key=getch();
            switch(key)
            {
                //SAISIE UTILISATEUR
            case 'z':
                indiceFleche -=2;
                bougerOptionChrono(*chrono,indiceFleche);
                break;
            case 's':
                indiceFleche +=2;
                bougerOptionChrono(*chrono,indiceFleche);
                break;
                //TRAiTEMENT DE LA SAISIE ET MODIFICATION DE LA VARIABLE D'AFFICHAGE DU CHRONO
            case 'e':
                if (modulo(indiceFleche,4) == 0)
                {
                    *chrono = 1;
                }
                if (modulo(indiceFleche,4) == 2)
                {
                    *chrono = 0;
                }
                keys ='v';
                break;
            }
        }
    }
}
void AffichageChrono(Pcman *pcm, int chrono) //Affiche le chronometre si demand� dans le menu
{
    if (chrono == 1)
    {
     gotoligcol(10,70);
    (*pcm).chrono=((*pcm).temps - (clock()- (*pcm).tempsPasse)/1000);
    printf("Plus que %f seconde ",(*pcm).chrono);
    }
}

void FinProgramme()
{
    system("cls");
    SetConsoleTextAttribute(GetStdHandle(STD_OUTPUT_HANDLE), 14);
    gotoligcol(10+12, 70);
    printf("Au revoir !");
    SetConsoleTextAttribute(GetStdHandle(STD_OUTPUT_HANDLE), 0);
}
