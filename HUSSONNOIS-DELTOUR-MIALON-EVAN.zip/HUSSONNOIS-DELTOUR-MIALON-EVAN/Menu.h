void pacmanAffichage();
void PremierEcran();
void menuOption();
void regles();

void bougerMenu(int indiceFleche);
void afficherFleche(int indiceFleche);



void modifVitesse(unsigned long int *temps, int indiceFleche);
void choixVitesse(unsigned long int *temps, int indiceFleche);
void ctrlVitesse();

