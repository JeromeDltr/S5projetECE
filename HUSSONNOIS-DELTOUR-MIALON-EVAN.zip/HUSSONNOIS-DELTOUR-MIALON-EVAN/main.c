#include <stdio.h>
#include <stdlib.h>
#include "main.h"
#include <time.h>
#include <windows.h>
#include "OutilsAutres.h"
#include "Deplacement.h"
#include "InitialisationPers.h"
#include "InteractionObjets.h"
#include "InteractionPersonnages.h"
#include "Plateau.h"
#include "Tableaux.h"
#include "Menu.h"

int main()
{
    typedef BOOL (WINAPI *PFONCTION) (HANDLE,DWORD,PCOORD);
    HMODULE hDLL=LoadLibrary("kernel32.dll");
    PFONCTION SetDisplayMode = (PFONCTION) GetProcAddress(hDLL,"SetConsoleDisplayMode");
    HANDLE hconsole = GetStdHandle(STD_OUTPUT_HANDLE);
    COORD coord;
    SetDisplayMode (hconsole,1,&coord);

    // DECLARATION DES VARIABLES
    //Variables li�es � la cr�ation du tableau
    int tab[20][50]= {0};

//Variable li� au menu
    int indiceFleche=0;

//Variables li�es au score
    int score=0;

//Variable de temps
    unsigned long temps=20;
//Variable de boucle infinie
    char key='a';

// Variable pour d�sactiver les murs, initialis� avec bordures
    int murOnOff = 1;
// Variable pour d�sactiver le chrono, initialis� avec
    int chrono = 1;
//Creation des variables personnages
    Pcman pcm[100];
    Pcman ennemi[4];
    Objet diamants[100];
    Objet Yukunkun;

    (diamants[0]).nombreDeDiamants=5;
    (pcm[0]).pointDeVie=5;
    srand(time(NULL));
    PremierEcran();
    menuOption();       //MENU D'ACCUEIL pour le choix des actions
    afficherFleche(indiceFleche);

    while (key!='v')
    {
        if(kbhit())
        {
            key=getch();
            switch(key)
            {
            case 'z':           //fait monter la fl�che
                indiceFleche -=2;
                bougerMenu(indiceFleche);
                break;
            case 's':           //fait descendre la fl�che
                indiceFleche +=2;
                bougerMenu(indiceFleche);
                break;
            case 'e':
                if (modulo(indiceFleche,14) == 0)       //REGLES DU JEU
                {
                    regles();
                    menuOption();
                    afficherFleche(indiceFleche);
                }
                if (modulo(indiceFleche,14) == 2)       //CHOIX DES VITESSES
                {
                    ctrlVitesse();
                    choixVitesse(&temps,0);
                    menuOption();
                    afficherFleche(indiceFleche);
                }
                if (modulo(indiceFleche,14) == 4)       //NOUVELLE PARTIE
                {
                    score = 0;
                    Reinitialisation(&pcm,ennemi,diamants,tab,&score,&key);
                    lvl1(&key, &temps, &score,pcm, ennemi, diamants,tab, murOnOff,&Yukunkun,chrono);
                    Reinitialisation(&pcm,ennemi,diamants,tab,&score,&key);
                    menuOption();
                    indiceFleche = 0;
                    afficherFleche(indiceFleche);
                }
                if (modulo(indiceFleche,14) == 6)       //REPRENDRE PARTIE
                {
                    Reinitialisation(&pcm,ennemi,diamants,tab,&score,&key);
                    ReprendreNiveau(&key, &temps, &score,pcm, ennemi, diamants,tab, murOnOff,&Yukunkun);
                    menuOption();
                    indiceFleche = 0;
                    afficherFleche(indiceFleche);
                }
                if (modulo(indiceFleche,14) == 8)       //ACTIVER/DESACTIVER LES BORDURES DES TABLEAUX
                {
                    OptionMur();
                    choixOptionMur(&murOnOff,0);
                    menuOption();
                    indiceFleche = 0;
                    afficherFleche(indiceFleche);
                }
                 if (modulo(indiceFleche,14) == 10)     //ACTIVER OU DESACTIVER L'OPTION DU CHRONOMETRE
                {
                    OptionChrono();
                    ChoixOptionChrono(&chrono,0);
                    menuOption();
                    indiceFleche = 0;
                    afficherFleche(indiceFleche);
                }

                if (modulo(indiceFleche,14) == 12)      // QUITTER :(
                    key ='v';

            }
        }

    }

    FinProgramme();     //petit affichage
    return 0;
}
