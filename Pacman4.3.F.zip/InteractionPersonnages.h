void ToucherCouper(Pcman pcm[100],Pcman *ennemi);
void Couper(Pcman *pcm);
void ToucherTete(char *key, unsigned long int *temps, int *score, Pcman pcm[100], Pcman ennemi[4], Objet diamants[100], int tab[20][50], int murOnOff, Objet *Yukunkun,int chrono);
void OnSeMordPas(Pcman pcm[100]);
void boucleToucherCouler(Pcman *pcm, Pcman ennemi[4]);
void ToucherCouler(Pcman *pcm,Pcman *ennemi);
void PerteDePointDeVie(pcm);
void LesFantomesNeMangesPas(Pcman *ennemi, Objet diamants[100], Objet *Yukunkun);
void NouvelleTete(Pcman pcm[100]);

