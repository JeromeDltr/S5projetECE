
typedef struct Pcman Pcman;
struct Pcman
{
    char nom;
    int coordonneX;
    int coordonneY;
    int vitesse;
    int compteurmvt;
    int pointDeVie;
    char direction;
};

typedef struct Objet Objet;
struct Objet
{
    char nom;
    int coordonneX;
    int coordonneY;
    int marque;
};
