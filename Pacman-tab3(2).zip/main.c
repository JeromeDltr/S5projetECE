#include <stdio.h>
#include <stdlib.h>
#include "main.h"
#include <time.h>
#include <windows.h>
#include "Personnage.h"
#include "Vieautonome.h"
#include "Plateau.h"



int main()
{
  // DECLARATION DES VARIABLES
  //Variables li�es � la cr�ation du tableau
  int largeurTab=50;
  int longueurTab=20;
  int tab[20][50]={0};



 //Variables li�es au score
  int score=0;

//Variable de temps     long temps= 1500000;
//Variable de boucle infinie
  char key='a';

//Creation des variables personnage
  Pcman pcm;
  Pcman ennemi[3];
  Objet diamants[5];

  srand(time(NULL));

  InitialisationPerso(&pcm,diamants,ennemi); //Initialise les
  CreationContour(largeurTab,longueurTab,tab);// Creation du niveau
  // GenerationNiveauAlea(tab); C'est la fonction qui g�n�re des murs al�atoirements, � am�liorer
  GenerationAleatoireDePcman(&pcm);
  GenerationAleatoireDePcman(&ennemi[0]);
  GenerationAleatoireDePcman(&ennemi[1]);
  GenerationAleatoireDePcman(&ennemi[2]);
  AffichagePacman(&pcm);
  GenerationAleatoireDeDiamants(largeurTab,longueurTab,diamants);

  while (key!='n')
    {
        Sleep(70);
        VieAutonome(&pcm, diamants,&score,tab);

        VieAutonomeEnnemie(&ennemi[0],tab,diamants,&pcm);
        VieAutonomeEnnemie(&ennemi[1],tab,diamants,&pcm);
        VieAutonomeEnnemie(&ennemi[2],tab,diamants,&pcm);
        MORT(&pcm,ennemi);

        if(kbhit())
        {
            key=getch();
            switch(key)
            {
                case 'd':
                    pcm.direction='d';
                    break;
                case 'q':
                    pcm.direction='q';
                    break;
                case 'z':
                    pcm.direction='z';
                    break;
                case 's':
                    pcm.direction='s';
                    break;
                default:
                    key = 'n';
                    printf("a bientot");
            }
        }

    }
}
