//http://blockofcodes.blogspot.com/2013/06/how-to-change-text-color-of-cc-console.html


//***************************************************PLATEAU********************************************************************************

//to change color

//Cr�ation niveau
void CreationContour( int tab[20][50], int murOnOff);
void GenerationNiveauAlea(int tab[20][50]);

// Placement des personnages et objets
void GenerationAleatoireDeDiamants(Objet diamants[100]);
void GenerationAleatoireDePcman(Pcman *pcm);

//Fonction d'affichage
void AffichagePacman(Pcman *pcm);
void AffichageBlanc(Pcman *pcm);
void AffichageScore(int *score);
void AffichagePointDeVie(Pcman *pcm);

void RegenerationDiamants(Objet diamants[5], int tab[20][50]);
void ReductionDEContour(int tab[20][50], int murOnOff, int largeur, int longueur, int reduction);

void ReductionContour(int tab[20][50], int murOnOff, int largeur, int longueur, int reduction, Pcman ennemi[4]);
void GenerationAleatoireObjet(Objet *objet);
void Clignotement(Pcman *pcm);
