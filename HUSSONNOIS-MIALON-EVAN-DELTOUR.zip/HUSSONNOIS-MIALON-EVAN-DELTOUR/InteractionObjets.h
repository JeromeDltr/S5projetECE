
void TestDefaite(Pcman *pcm, char *key,int*score, int chrono);

int CompteurScore(int *score, Pcman *pcm, Objet diamants[100]);
int CompteurScoreSnake(int *score,Objet diamants[100], Pcman pcm[100], Objet *Yukunkun) ;
void Duree(Objet *objet);

int TestVictoirelvl4(Objet diamants[100],char *key);
