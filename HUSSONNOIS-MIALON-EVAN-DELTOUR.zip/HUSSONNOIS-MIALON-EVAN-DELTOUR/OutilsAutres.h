int MinTab(double tab[4], int tailleTab);
int modulo(int x,int N);//modulo sur N(entiers naturels)
void gotoligcol(int lig, int col);


