#include <stdio.h>
#include <stdlib.h>
#include "main.h"
#include <windows.h>
#include <time.h>
#include "ListeFonctions.h"





void CreationContour(int tab[20][50], int murOnOff) // Cr�er les contours du terrain
{
    int i;
    SetConsoleTextAttribute(GetStdHandle(STD_OUTPUT_HANDLE), 135);
    for (i=0; i<50; i++)
    {
        gotoligcol(0+12,i+60);
        tab[0][i]='1';
        if(murOnOff==1)
            printf("#");
    }
    for (i=0; i<50; i++)
    {
        gotoligcol(20+12,i+60);
        tab[20][i]='1';
        if(murOnOff==1)
            printf("#");
    }
    for (i=0; i<20; i++)
    {
        gotoligcol(i+12,0+60);
        tab[i][0]='1';
        if(murOnOff==1)
            printf("#");
    }
    for (i=0; i<20; i++)
    {
        gotoligcol(i+12,50-1+60);
        tab[i][50-1]='1';
        if(murOnOff==1)
            printf("#");
    }
    SetConsoleTextAttribute(GetStdHandle(STD_OUTPUT_HANDLE), 15);
}

void GenerationNiveauAlea(int tab[20][50])  //G�n�rer des murs globalements al�atoirement pour le niveau 3
{
    int i=2,j=2;
    int nombreMurX=30; // Initialisation arbitraire du nombre de mur qu'on vas poser en ligne
    int MurOuPasMur;   // Boolean, variable al�atoire qui vas d�cider avec 1/2 de poser un mur ou non
    int nombreMurY=20;   // Initialsation arbitraire du nombre de mur qu'on va poser en colonne
    // PS: les initialisations arbitraire corresponde au test effectu� avec un r�sultat le plus satisfaisant

    SetConsoleTextAttribute(GetStdHandle(STD_OUTPUT_HANDLE), 135);
    while(nombreMurX!=0)
    {
        MurOuPasMur=rand()%2; // Une chance sur deux de poser le mur sur cette colonne
        if (MurOuPasMur==0)
        {
            nombreMurX--;     // on d�cr�mante ce nombre
            nombreMurY=20;    // on initialise le nombre de mur qu'on va poser sur cette colonne
            while(nombreMurY!=0)
            {
                MurOuPasMur=rand()%2;  // une chance sur deux de poser le
                if (MurOuPasMur==0)
                {
                    nombreMurY--;
                    tab[j][i]='2';
                    gotoligcol(j+12,i+60);
                    printf("#");
                }
                j+=4;
                j=j%18 +2;
            }
        }
        i+=1;
        i=i%48  ;
    }
    SetConsoleTextAttribute(GetStdHandle(STD_OUTPUT_HANDLE), 15);
}


void GenerationAleatoireDeDiamants(Objet diamants[5]) // Place les diamants de mani�re al�atoires sur le plateau
{
    int i=0;
    SetConsoleTextAttribute(GetStdHandle(STD_OUTPUT_HANDLE), 14);

    for (i=0; i<5; i++)
    {
        do
        {
            (diamants)[i].coordonneX=(rand()%(50-2)) +1;
            (diamants)[i].coordonneY=(rand()%(20-2)) +1;
            gotoligcol(((diamants)[i]).coordonneY+12,((diamants)[i]).coordonneX+60);
        }
        while(((diamants)[i].coordonneY == 2) || ((diamants)[i].coordonneY == 8) || ((diamants)[i].coordonneY == 14));
        printf("%c",((diamants)[i]).nom);
    }
    SetConsoleTextAttribute(GetStdHandle(STD_OUTPUT_HANDLE), 15);
}
void GenerationAleatoireObjet(Objet *objet)
{
    SetConsoleTextAttribute(GetStdHandle(STD_OUTPUT_HANDLE), 14);

    (*objet).coordonneX=(rand()%(50-2)) +1;
    (*objet).coordonneY=(rand()%(20-2)) +1;
    (*objet).duree=60;
    gotoligcol((*objet).coordonneY+12,(*objet).coordonneX+60);

    printf("%c",(*objet).nom);
    (*objet).nombreDeYukunkun++;
    SetConsoleTextAttribute(GetStdHandle(STD_OUTPUT_HANDLE), 15);

}

void GenerationAleatoireDePcman(Pcman *pcm)  //Place un personnage de mani�re al�atoire sur le terrain
{
    char tabd[4];
    int i;
    tabd[0]='s';
    tabd[1]='d';
    tabd[2]='q';
    tabd[3]='z';
    i=rand()%4;
    (*pcm).direction=tabd[i];
    (*pcm).coordonneX=(rand()%(50-2)) +1;
    (*pcm).coordonneY=(rand()%(20-2)) +1;
}


void AffichagePacman(Pcman *pcm)  //Affiche le Pacman
{
    gotoligcol((*pcm).coordonneY+12,(*pcm).coordonneX+60);
    if ((*pcm).couleur==0)
    {
        SetConsoleTextAttribute(GetStdHandle(STD_OUTPUT_HANDLE), 31);
        printf("%c",(*pcm).nom);
        gotoligcol(25, 55);
    }
    else
    {
        SetConsoleTextAttribute(GetStdHandle(STD_OUTPUT_HANDLE), 64);
        printf("%c",(*pcm).nom);
        gotoligcol(25, 55);
    }
    SetConsoleTextAttribute(GetStdHandle(STD_OUTPUT_HANDLE), 15);
}

void AffichageBlanc(Pcman *pcm)  //Efface le Pacman
{
    gotoligcol((*pcm).coordonneY+12,(*pcm).coordonneX+60);
    printf(" ");
}

void AffichageScore(int *score) //Affiche le score
{
    gotoligcol(24+12,70);
    printf(" Le score est de");
    printf(ANSI_COLOR_RED " %d",*score);
    printf(ANSI_COLOR_RESET"");
}

void AffichagePointDeVie(Pcman *pcm)  // Affiche les points de vie
{
    gotoligcol(22+12,70);
    printf(" Il te reste ");
    printf(ANSI_COLOR_MAGENTA "%d ",(*pcm).pointDeVie);
    printf(ANSI_COLOR_RESET"point de vie");
}



