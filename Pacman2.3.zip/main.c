#include <stdio.h>
#include <stdlib.h>
#include "main.h"
#include <time.h>
#include <windows.h>
#include "ListeFonctions.h"


int main()
{
    // DECLARATION DES VARIABLES
    //Variables li�es � la cr�ation du tableau
    int largeurTab=50;
    int longueurTab=20;
    int tab[20][50]= {0};
//Variable li� au menu
    int indiceFleche=0;

//Variables li�es au score
    int score=0;

//Variable de temps
    unsigned long temps=100;
//Variable de boucle infinie
    char key='a';

//Creation des variables personnages
    Pcman pcm;
    Pcman ennemi[4];
    Objet diamants[5];

// Variable pour d�sactiver les murs
    int murOnOff;

    srand(time(NULL));
    PremierEcran();
    menuOption();
    OptionMur(&murOnOff);
    gotoligcol(27, 2);
    printf("murOnOff = %d", murOnOff);
    afficherFleche(indiceFleche);

    while (key!='v')
    {
        if(kbhit())
        {
            key=getch();
            switch(key)
            {
            case 'z':
                indiceFleche -=2;
                bougerMenu(indiceFleche);
                break;
            case 's':
                indiceFleche +=2;
                bougerMenu(indiceFleche);
                break;
            case 'e':
                if (indiceFleche%6 == 0)
                {
                    regles();
                    menuOption();
                    afficherFleche(indiceFleche);
                }
                if (indiceFleche%6 == 2)
                {
                    ctrlVitesse();
                    choixVitesse(&temps,0);
                    menuOption();
                    afficherFleche(indiceFleche);
                }
                if (indiceFleche%6 == 4)
                {
                    lvl1(&key, &temps, &score,&pcm, ennemi, diamants,tab, murOnOff);
                    Reinitialisation(&pcm,ennemi,diamants,tab,&score,&key);
                    menuOption();
                    afficherFleche(0);
                    indiceFleche=0;
                }
                break;
            }
        }

    }

    return 0;
}
