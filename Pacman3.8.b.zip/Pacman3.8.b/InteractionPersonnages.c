#include <stdio.h>
#include <stdlib.h>
#include "main.h"
#include <windows.h>
#include <time.h>
#include "ListeFonctions.h"
void ToucherCouler(Pcman *pcm,Pcman *ennemi)  //  Test la collision sur un ennemi
{

        if (((*ennemi).coordonneY==(*pcm).coordonneY) && ((*ennemi).coordonneX==(*pcm).coordonneX)) // On test si le fant�me est au m�me endroit que le pacman
        {
            (*pcm).pointDeVie-=1; // On retire un point de vie au pacman
            Clignotement(pcm);  // on le fait clignoter
            if ((*pcm).snakeON==1)  // Si le mode snake est ouvert
            {
                (*pcm).toucher=1;  // on signale que le snake a �t� toucher
            }
        }
}
void boucleToucherCouler(Pcman *pcm, Pcman ennemi[4]) // Test la collision sur tout les ennemis
{
    int i = 0;
    for (i=0;i<4;i++)
    {
        ToucherCouler(pcm,&ennemi[i]);
    }
}
void LesFantomesNeMangesPas(Pcman *ennemi, Objet diamants[100], Objet *Yukunkun)  // Empeche les fantomes de manger des diamants
{
    int i=0;
    SetConsoleTextAttribute(GetStdHandle(STD_OUTPUT_HANDLE), 14);


    for (i=0; i<(diamants[0]).nombreDeDiamants; i++)  // On boucle sur tout les diamants
    {
        if (((*ennemi).coordonneY==(diamants[i]).coordonneY) && ((*ennemi).coordonneX==(diamants[i]).coordonneX)) // on test si l'ennemi est sur la m�me position qu'un diamant
        {
            gotoligcol((*ennemi).coordonneY+12,(*ennemi).coordonneX+60); // on se replace � la position du diamant et on l'affiche
            printf("D");
        }
    }
    if (((*ennemi).coordonneY==(*Yukunkun).coordonneY) && ((*ennemi).coordonneX==(*Yukunkun).coordonneX)) // on fait de m�me pour le Yukunkun
        {
            gotoligcol((*ennemi).coordonneY+12,(*ennemi).coordonneX+60);
            printf("*");
        }

    SetConsoleTextAttribute(GetStdHandle(STD_OUTPUT_HANDLE), 15);
}

void NouvelleTete(Pcman snake[100]) // Ajoute les nouvelles t�tes
{
    (snake[0]).nombreDeTete++; // On met � jour le nombre de t�te
    snake[(snake[0]).nombreDeTete-1].nom='o'; // On lui donne son nom

    // On donne � la nouvelle queux les positions pr�c�dentes, la direction de la queue pr�cedente
    snake[(snake[0]).nombreDeTete-1].direction=snake[(snake[0]).nombreDeTete-2].direction;
    snake[(snake[0]).nombreDeTete-1].coordonneX=snake[(snake[0]).nombreDeTete-2].coordonneXv;
    snake[(snake[0]).nombreDeTete-1].coordonneY=snake[(snake[0]).nombreDeTete-2].coordonneYv;
    snake[(snake[0]).nombreDeTete-1].pointDeVie=snake[(snake[0]).nombreDeTete-2].pointDeVie;
}
void ToucherCouper(Pcman pcm[100],Pcman *ennemi) // Test si il y a collision entre un fant�me et une queux
{
    // DECLARATION DES VARIABLES
    int i,j,taille;
    taille=pcm[0].nombreDeTete + 1;

    for (i=1;i<taille;i++) // pour chacune des queuex
    {
         if (((*ennemi).coordonneY==(pcm)[i].coordonneY) && ((*ennemi).coordonneX==(pcm)[i].coordonneX)) // on test si il y a collision avec l'ennemi
        {
            for (j=i;j<taille;j++)  //  Si oui pour la i-�me, on enleve chacun des queux � partir de la i-�me et on r�duit le nombre de t�te
            {
                AffichageBlanc(&pcm[j]);
                Couper(&pcm[j]);
                pcm[0].nombreDeTete--;

            }
            pcm[0].nombreDeTete++ ; // On ajuste le nombre de t�te
        }
    }
}
void Couper(Pcman *pcm) // Enleve les queux
{
    AffichageBlanc(pcm); // On efface et on rends son deplacement invisible
    (*pcm).nom=' ';
    (*pcm).compteurmvt=0;
    (*pcm).direction='d';
    (*pcm).vitesse=1;
    (*pcm).vitesseON=0;
    (*pcm).couleur=0;

}
void ToucherTete(char *key, unsigned long int *temps, int *score, Pcman pcm[100], Pcman ennemi[4], Objet diamants[100], int tab[20][50], int murOnOff, Objet *Yukunkun) // Enl�ve toute les queux du pacman quand il a �t� touch�� la t�te
{
    //DECLARATION DES VARIABLES
    int j,taille;
    taille=pcm[0].nombreDeTete + 1;


    if((pcm)[0].toucher==1) // Test si le pacman � bien �t� toucher � la t�te
    {
        for (j=1;j<taille;j++)  // On enl�ve toutes les queux du pacman
            {
                AffichageBlanc(&pcm[j]);
                Couper(&pcm[j]);
                pcm[0].nombreDeTete--;

            }
        pcm[0].nombreDeTete++;
        (pcm)[0].toucher=0;

        lvl4(key, temps, score,pcm, ennemi, diamants,tab, murOnOff,Yukunkun); // On relance le niveau

    }
}
void OnSeMordPas(Pcman pcm[100]) // Gere les colissions entre la t�te du pacman et ses queux
{
    int i;

    for (i=1;i<pcm[0].nombreDeTete+1;i++) // On test si il y a colission entre la t�te du pacman et ses queux
    {
        if (((pcm[0]).coordonneY==(pcm)[i].coordonneY) && ((pcm[0]).coordonneX==(pcm)[i].coordonneX))
            {
                pcm[0].pointDeVie--; // Si oui, on enl�ve une vie
                (pcm)[0].toucher=1; // On met � jur l'attribut qui va relancer le tableau
            }
    }
}

void PerteDePointDeVie(Pcman *pcm) // Retire un point de vie au pacman
{
    (*pcm).pointDeVie-=1; // On lui retire et on le fait clignoter
    Clignotement(pcm);
}
