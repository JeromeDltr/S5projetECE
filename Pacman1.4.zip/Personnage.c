#include <stdio.h>
#include <stdlib.h>
#include "main.h"
#include <windows.h>
#include <time.h>
#include "Plateau.h"
// INITIALISATION DES PARAMETRES
void InitialisationPerso(Pcman *pcm)
{
    (*pcm).nom='X';
    (*pcm).coordonneX=2;
    (*pcm).coordonneY=1;
    (*pcm).compteurmvt=0;
    (*pcm).direction='d';
    (*pcm).pointDeVie=5;
    (*pcm).vitesse=1;
    (*pcm).vitesseON=0;
}

void initialisationObjet(Objet diamants[5])
{
    int i;

    for(i=0; i<5; i++)
    {
        (diamants)[i].nom='*';
        (diamants)[i].coordonneX=0;
        (diamants)[i].coordonneY=0;
        (diamants)[i].marque=2;
    }
}
void initialisationEnnemi(Pcman ennemi[4])
{
    int i, val = 0;
    for(i=0; i<4; i++)
    {
        (ennemi[0]).nom='E';
        (ennemi[0]).coordonneX=3+2*i;
        (ennemi[0]).coordonneY=3+2*i;
        (ennemi[0]).compteurmvt=0;
        (ennemi[0]).direction='d';
    }
}
void InitialisationEnnemiIA(Pcman ennemi[4])
{
    int i;
    for(i=0; i<4; i++)
        (ennemi[i]).IAON='1';
}

void InitialisationVitesseON(Pcman *pcm)
{
    (*pcm).vitesseON=1;
}

// DEPLACEMENT
void AvancementX(Pcman *pcm)
{
    (*pcm).coordonneX+=1;
}
void ReculX(Pcman *pcm)
{
    (*pcm).coordonneX-=1;
}
void AvancementY(Pcman *pcm)
{
    (*pcm).coordonneY-=1;
}
void ReculY(Pcman *pcm)
{
    (*pcm).coordonneY+=1;
}
void RetourX(Pcman *pcm)
{
    (*pcm).coordonneX-=1;
}
void RetourXG(Pcman *pcm)
{
    (*pcm).coordonneX+=1;
}
void RetourY(Pcman *pcm)
{
    (*pcm).coordonneY-=1;
}
void RetourYH(Pcman *pcm)
{
    (*pcm).coordonneY+=1;
}
