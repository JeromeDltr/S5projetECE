
typedef struct Pcman Pcman;
struct Pcman
{
    char nom;
    int coordonneX;
    int coordonneY;
    int compteurmvt;
    char direction;


};
