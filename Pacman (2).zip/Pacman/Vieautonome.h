#ifndef Vieautonome
#define Vieautonome
void VieAutonome(Pcman *pcmn,Pcman *point, int *score, int *Pomme, int tab[20][50]);
void VieAutonomeEnnemie(Pcman *pcm, int tab[20][50]);
void changementDirEnnemie(Pcman *pcm);
void ConditionChangementDir(Pcman *pcm);
#endif
