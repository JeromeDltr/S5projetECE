#include <stdio.h>
#include <stdlib.h>
#include "main.h"
#include <time.h>
#include <windows.h>
#include "Personnage.h"
#include "Vieautonome.h"
#include "Plateau.h"



int main()
{
  // DECLARATION DES VARIABLES
  int i=0;
  //Variables li�es � la cr�ation du tableau
  int largeurTab=50;
  int longueurTab=20;
  int tab[20][50]={0};



 //Variables li�es au score
  int score=0;
  int scoreF=0;
  int Pomme=1;

//Variable de temps
  long temps=150;
//Variable de boucle infinie
  char key='a';
//Creation des variables personnage
  Pcman pcm,point;
  Pcman ennemi[3];

  srand(time(NULL));

  InitialisationPerso(&pcm,&point,&ennemi); //Initialise les
  CreationContour(largeurTab,longueurTab,tab); // Creation du niveau
  AffichagePacman(&pcm);


  while (key!='n')
    {
        Sleep(temps);
        VieAutonome(&pcm,&point,&score,&Pomme,tab);

        VieAutonomeEnnemie(&ennemi[0],tab);
        VieAutonomeEnnemie(&ennemi[1],tab);
        VieAutonomeEnnemie(&ennemi[2],tab);


        if(kbhit())
        {
            key=getch();
            switch(key)
            {
                case 'd':
                    pcm.direction='d';
                    break;
                case 'q':
                    pcm.direction='q';
                    break;
                case 'z':
                    pcm.direction='z';
                    break;
                case 's':
                    pcm.direction='s';
                    break;
                case 'n':
                    printf("a bient�t");
            }
        }
        else if ((pcm.compteurmvt==20) && (Pomme==1))
            {
                GenerationAleatoireObjet(largeurTab,longueurTab,&point,tab);
                pcm.compteurmvt=0;
                Pomme=0;
            }
    }
}
